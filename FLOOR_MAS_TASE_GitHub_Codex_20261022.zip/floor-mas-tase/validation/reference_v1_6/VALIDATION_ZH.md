# v1.6交付验证记录

- 11项单元/机制/接入测试通过，包括14个JRS-RG配置的实际回合与轨迹审计。
- 最终源码执行CPU smoke：3个基础世界、3条件、22方法，共198回合，执行错误0；完整任务产物、轨迹及冻结信息随包提供。
- Python编译与两个Shell入口语法检查通过；结果汇总、配对统计、因子统计和PDF/PNG绘图已运行。
- 最终交付的src/scripts源码散列与release_smoke_cpu/FREEZE.json记录一致。
- 本机无CUDA运行环境，没有执行GPU计时或CPU/CUDA一致性测试；服务器入口为scripts/benchmark_v16.py。

本地smoke观察：base为JRS-RG 1/3、原始JRS 3/3；failure_high均为2/3；deadline_tight为JRS-RG 1/3、原始JRS 3/3。规划墙钟也高于冻结v1.5。因此本包是新架构的可运行研究版本，尚未达到“保持速度并提高完成率”的性能验收。下一步应先运行GPU probe，重点检查新增缺陷的诊断时机、模型对次生损伤后续传播的低估、以及图编译相对GPU评估的时间占比。

这3世界只用于执行与诊断，不能据此推断总体优劣。无需为了得到正向结果删掉失败世界、改变质量要求或调整原J定义。开发完成后，用独立main世界一次性比较全部配置。

实际结果见release_smoke_analysis/RESULTS_ZH.md、speed_acceptance.csv；主目标见primary_acceptance.csv。smoke的每布局只有1个世界，分层bootstrap区间会退化，不用于论文显著性结论。
