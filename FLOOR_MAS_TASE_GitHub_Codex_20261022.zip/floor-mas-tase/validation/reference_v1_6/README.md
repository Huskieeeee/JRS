# Original v1.6 evidence

These reports, protocol, completion record, and source freeze were copied unchanged from the uploaded v1.6 archive. Their source hashes identify the original layout, before package reorganization. Raw per-job files and runtime snapshots remain in that original archive, identified by `docs/archive/IMPORT_PROVENANCE.json`.

This compact reference is historical evidence and is not a resumable run directory. New checks use new output directories and record the reorganized source. Do not overwrite these reference reports with newer results.
