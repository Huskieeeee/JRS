# v1.6 主验收读数

|条件|完成差pp|同时区间下界pp|同时区间上界pp|
|---|---:|---:|---:|
|base|-66.67|-66.67|-66.67|
|failure_high|0.00|0.00|0.00|
|deadline_tight|-66.67|-66.67|-66.67|

区间按基础世界、布局分层配对重抽样，三项主比较使用Bonferroni水平。3世界smoke的区间可退化，只用于执行检查。
主结果RESULTS_ZH.md；全部对照ALL_BASELINES_ZH.md；机制mechanisms.csv；交互factorial_effects.csv；速度验收speed_acceptance.csv。