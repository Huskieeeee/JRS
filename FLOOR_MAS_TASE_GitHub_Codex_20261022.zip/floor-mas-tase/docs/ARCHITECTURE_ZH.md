# 架构与代码定位

项目分成场景执行、规划决策和实验评估三个部分。此次整理主要把原来依赖 `scripts/` 相互导入的实验实现迁入正式包，算法模块保留原路径，便于和 v1.6 对照。

| 层次 | 主要文件 | 输入与输出 |
|---|---|---|
| 场景与物理执行 | `model.py`、`environment.py`、`paired_worlds.py` | 场景、观测与动作 → 执行事件、质量状态与原始指标 |
| JRS-RG | `recovery_graph.py`、`rg_variants.py` | 当前公开观测 → 恢复图、候选评分、联合动作和续接状态 |
| 其他研究方法 | `planners.py`、`handoff.py`、`adaptive_handoff.py`、`joint_recovery.py`、`evidence_recovery.py`、`release_planner.py` | 各版本方法及对照，与同一环境对接 |
| 预测模型 | `surrogate.py`、`ensemble.py`、`prediction.py`、`models/` | 候选特征与固定参数 → 预测量，供相关对照使用 |
| 实验配置 | `experiments/campaigns.py` | 阶段、设备、分片 → 配对任务协议 |
| 实验执行 | `experiments/runner.py` | 协议 → 冻结记录、逐回合产物、完整性记录 |
| 汇总与展示 | `experiments/analysis.py`、`reporting.py`、`plotting.py` | 完整配对结果 → 指标、对照、因子统计和图 |
| 计算实验 | `experiments/benchmark.py`、`budget.py`、`merge.py` | 同一候选/世界 → 设备一致性、计算预算曲线、分片合并 |

```mermaid
flowchart TD
    A["配置与配对世界"] --> B["实验执行器"]
    B --> C["规划器：JRS-RG 与对照"]
    C --> D["场景执行与轨迹审计"]
    D -->|下一次公开观测| C
    D --> E["冻结产物与逐回合记录"]
    E --> F["统计、机制分析与绘图"]
```

## 入口迁移表

| 原入口，继续兼容 | 当前实现 | 新命令 |
|---|---|---|
| `scripts/prepare_v16.py` | `experiments/campaigns.py` | `floor-tase prepare` |
| `scripts/run_repair_round.py` | `experiments/runner.py` | `floor-tase run` |
| `scripts/analyze_repair_round.py` | `experiments/analysis.py` | `floor-tase analyze` |
| `scripts/report_v16.py` | `experiments/reporting.py` | `floor-tase report` |
| `scripts/plot_v16.py` | `experiments/plotting.py` | `floor-tase plot` |
| `scripts/benchmark_v16.py` | `experiments/benchmark.py` | `floor-tase benchmark` |
| `scripts/merge_v16.py` | `experiments/merge.py` | `floor-tase merge` |
| `scripts/run_budget_v16.py` | `experiments/budget.py` | `floor-tase budget` |
| `scripts/check_gpu.py` | `experiments/gpu.py` | `floor-tase gpu` |

实验模块从已安装的可编辑 checkout 定位配置与模型；从其他工作目录执行也可找到这些资源。若分开安装 wheel 与源码，设置 `FLOOR_TASE_ROOT` 指向包含 `pyproject.toml`、`configs/` 和 `models/` 的 checkout。wheel 不捆绑实验数据。

原科学模块保持平铺布局以保留旧导入；后续按规划、环境、预测进一步拆分时，应单独提交并核对固定场景行为。对代码可读性的大规模格式化也单独开展，避免和算法改动混合。
