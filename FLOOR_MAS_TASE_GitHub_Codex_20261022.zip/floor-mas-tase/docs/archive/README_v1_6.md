# FLOOR MAS T-ASE Handoff v1.6 — JRS-RG

本版直接实现恢复依赖图调度、批量随机完成时间评估和事件驱动执行。交付内容包括CPU/CUDA内核、22种方法及完整内部消融、单/多GPU脚本、配对统计、计算预算曲线和科研绘图。

详细动机、三问题—三方案、方法差异和实验设计见 `docs/INNOVATION_AND_EXPERIMENTS_ZH.md`。

## 1. 进入目录与安装

将ZIP放到 `/remote-home/share/dmb_nas2/liulingcheng/JRS`，在服务器依次执行：

```bash
cd /remote-home/share/dmb_nas2/liulingcheng/JRS
python -m zipfile -e FLOOR_MAS_TASE_Handoff_v1_6_20261021.zip handoff_v1_6
cd /remote-home/share/dmb_nas2/liulingcheng/JRS/handoff_v1_6/FLOOR_MAS_TASE_Handoff_v1_6
conda activate jrs
python -m pip install -e .
python -m unittest discover -s tests -v
CUDA_VISIBLE_DEVICES=4 python scripts/check_gpu.py --require-cuda
```

沿用现有jrs环境中已经验证可用的Torch CUDA安装。本包不会替换GPU驱动，也不需要重新训练v1.5模型。示例GPU编号4需按当前空闲情况选择。

## 2. GPU执行检查与一致性检查

```bash
CUDA_VISIBLE_DEVICES=4 bash scripts/run_v16.sh smoke 1 cuda
CUDA_VISIBLE_DEVICES=4 python scripts/benchmark_v16.py --device cuda
cat analysis/server_v16_smoke_cuda/READOUT_ZH.md
cat analysis/server_v16_smoke_cuda/speed_acceptance.csv
```

smoke：3世界×3条件×22方法=198回合。benchmark核对同一批图的CPU/CUDA评分与候选选择，并输出包含传输和同步的预热计时；本地无CUDA设备，需在服务器完成这一项。

## 3. 开发probe

```bash
mkdir -p logs
nohup env CUDA_VISIBLE_DEVICES=4 bash scripts/run_v16.sh probe 1 cuda > logs/server_v16_probe_cuda.log 2>&1 &
echo $! > logs/server_v16_probe_cuda.pid
tail -f logs/server_v16_probe_cuda.log
```

Ctrl+C只退出tail。检查：

```bash
cat results/server_v16_probe_cuda/COMPLETION.json
cat analysis/server_v16_probe_cuda/READOUT_ZH.md
cat analysis/server_v16_probe_cuda/RESULTS_ZH.md
cat analysis/server_v16_probe_cuda/speed_acceptance.csv
```

probe共792回合，用来完成最终参数与预测模型检查。主实验配置在生成时冻结；不根据主实验结果继续修改同一批实验。

## 4. 主实验：包含全部内部消融

单GPU：

```bash
nohup env CUDA_VISIBLE_DEVICES=4 bash scripts/run_v16.sh main 1 cuda > logs/server_v16_main_cuda.log 2>&1 &
echo $! > logs/server_v16_main_cuda.pid
```

两张GPU分片（选择这一条时不要同时启动上面的单GPU任务）：

```bash
nohup bash scripts/run_v16_multi.sh main 4,5 > logs/server_v16_main_multi.log 2>&1 &
echo $! > logs/server_v16_main_multi.pid
```

每GPU一个进程，按基础世界分片，每个世界内的所有方法和条件保持配对。分片改变不改变世界、观测或规划种子。多GPU最终输出：

```bash
cat results/server_v16_main_cuda_merged/COMPLETION.json
cat analysis/server_v16_main_cuda_merged/READOUT_ZH.md
cat analysis/server_v16_main_cuda_merged/ALL_BASELINES_ZH.md
cat analysis/server_v16_main_cuda_merged/speed_acceptance.csv
python scripts/plot_v16.py --analysis analysis/server_v16_main_cuda_merged
```

单GPU对应目录去掉`_merged`。合并结果通过链接引用分片任务目录，因此保留所有`results/server_v16_main_cuda_shard_*`目录。

主实验为600世界×5条件×22方法=66,000回合。smoke约每198回合产生55MB原始记录，主实验磁盘量级可按约20GB预留并以服务器实际结果为准；报告和图远小于原始记录。

## 5. 计算预算曲线

```bash
nohup env CUDA_VISIBLE_DEVICES=4 python scripts/run_budget_v16.py --device cuda --workers 1 > logs/server_v16_budget.log 2>&1 &
```

4种候选上限×60世界×3条件×4种搜索方法=2,880回合。输出`analysis/v16_budget_curve_cuda_4_8_16_32.csv`。也可用`--caps 4`等分别运行不同上限，每种输出目录独立。

## 6. 关键文件

- `src/floor_tase/recovery_graph.py`：恢复图编译、NumPy/Torch评估器、事件续接。
- `src/floor_tase/rg_variants.py`：22方法和J/U/E全因子开关。
- `scripts/prepare_v16.py`：smoke/probe/main配置、种子和GPU分片。
- `scripts/run_v16.sh`、`scripts/run_v16_multi.sh`：运行、合并、汇总。
- `scripts/report_v16.py`：主验收、全基线、完整消融与速度读数。
- `scripts/benchmark_v16.py`：CPU/CUDA一致性和延迟。
- `scripts/run_budget_v16.py`：计算投入曲线实验。
- `scripts/plot_v16.py`：输出PDF和PNG科研图。
- `validation/`：本地测试日志与CPU smoke报告。

## 7. 结果读取与中断恢复

`COMPLETION.json`中`data_complete=true`、`errors=0`表示冻结任务清单执行完整。按期合格完成率和速度目标查看`primary_acceptance.csv`与`speed_acceptance.csv`；完成执行不等于达到性能目标。

在源码、模型和配置未变时，重跑同一命令会校验并复用已完成任务。若任务产生`execution_error`，先查看该任务的`result.json`中的完整traceback。修复源码后使用新的输出目录保存整批实验，不把不同代码版本混入同一结果。

原始v1.5对照保留已修复的provider候选标识处理，避免先前StopIteration问题；新JRS-RG内核不依赖provider候选。
