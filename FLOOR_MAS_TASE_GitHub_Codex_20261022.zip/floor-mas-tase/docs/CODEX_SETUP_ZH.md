# Codex 开发环境配置

本仓库已经提供项目内所需的安装、检查与说明文件。GitHub 仓库授权和 Codex 账号内云环境发布是独立操作；仅提交这些文件不会自动创建云环境。

## 当前 Codex Cloud

按照 2026-10-21 查阅的 OpenAI 官方说明，在网页或桌面新任务中选择 `Work in > Cloud > Select environment > Create environment`，选择此私有 GitHub 仓库，再开始准备环境。也可从 `Settings > Codex Cloud > Environments` 创建。

在环境准备对话中给出：

```text
为这个仓库准备 Python 3.12 CPU 开发环境。
先读取 AGENTS.md 和 README.md。
安装命令：bash scripts/dev/setup.sh
验证命令：bash scripts/dev/check.sh
不需要常驻服务。保持私有访问。使用包管理器网络访问以安装依赖。
准备并测试通过后，给出环境报告。
```

安装项对应 `Install script`；任务启动只需确认工作目录与环境检查，不需要服务。需要时在环境设置中添加下列变量：

| 变量 | 值 | 作用 |
|---|---|---|
| `MPLBACKEND` | `Agg` | 无图形界面绘图 |
| `OMP_NUM_THREADS` | `1` | 避免多进程线程过量 |
| `MKL_NUM_THREADS` | `1` | 同上 |
| `OPENBLAS_NUM_THREADS` | `1` | 同上 |

审阅测试报告并选择 `Publish` 后，新任务才能使用此环境。更新可复用环境时编辑、测试并 `Republish`；已有任务保留自身状态。项目执行本身无需 OpenAI API key。

若使用旧版 Codex Cloud 集成环境，Setup script 同样填写 `bash scripts/dev/setup.sh`；维护时重新执行安装，以适配当前 checkout 的依赖。当前云环境与旧版集成环境的设置界面不同。

## 本地 Codex / 服务器

在 checkout 中执行：

```bash
python3 -m venv .venv
source .venv/bin/activate
bash scripts/dev/setup.sh
bash scripts/dev/check.sh
```

之后用 Codex 打开项目根目录。`AGENTS.md` 提供持续的项目说明。安装 Codex、登录与账户权限由本地应用管理；仓库不包含认证数据，也不修改用户全局 Codex 设置。

VS Code / Codespaces 可直接打开本仓库的 Dev Container。Python 3.12 的直接依赖参考版本在 `requirements/constraints-py312.txt`；要使用这些版本，可执行 `python -m pip install -c requirements/constraints-py312.txt -e .`。这份文件不是完整传递依赖锁。

## GPU 服务器

日常 Codex 环境选择 CPU。GPU 一致性、延迟与主实验应在实际具有 CUDA 的环境中执行，运行前检查 `floor-tase gpu --require-cuda`。已有 `jrs` 环境直接安装本项目，保留已经验证的 Torch。未安装 Torch 的环境需要按服务器驱动另行安装匹配版本。

## 第一条开发任务

```text
读取 AGENTS.md、README.md 和 docs/DEVELOPMENT_ZH.md。
先完成 CPU 检查，然后剖析 recovery_graph.py 的图编译与评估耗时。
使用独立开发世界，给出耗时分解和可复现命令。
优先优化反复分配和编译开销，保持质量要求、原 J、配对种子与方法集合一致。
修改后执行机制测试和开发 smoke，并汇报行为变化及实测结果。
```

官方资料：[Cloud environments](https://learn.chatgpt.com/docs/environments/cloud-environments)、[AGENTS.md](https://learn.chatgpt.com/docs/agent-configuration/agents-md)、[Local environments](https://learn.chatgpt.com/docs/environments/local-environment)。本地环境快捷动作通过桌面应用配置并生成，不在仓库中编造未验证的配置格式。
