# 上传 GitHub

建议仓库名 `floor-mas-tase`，可见性为 Private。

## 通过本对话继续上传

1. 在 GitHub 新建私有仓库。可选择初始化 README，以建立默认分支。
2. 在 GitHub 的 ChatGPT/Codex 应用授权中允许访问该仓库。
3. 将仓库链接提供给本对话。现有连接能够写入已授权仓库，但没有新建仓库的接口。

上传前本地整理和检查已经独立完成；授权后可以从整理好的源码树继续提交，无需重新整理。

## 本地终端直接上传

解压工程包，进入 `floor-mas-tase`，先运行安装与检查。安装并登录 GitHub CLI 后：

```bash
gh auth login
bash scripts/dev/publish_github.sh YOUR_OWNER/floor-mas-tase
```

该脚本创建私有仓库并推送 `main`。如果仓库已经存在，请使用下面的普通 Git 命令；先核对远程内容，保留已有提交，不使用强制推送。

```bash
git remote add origin https://github.com/YOUR_OWNER/floor-mas-tase.git
git push -u origin main
```

若工程包不包含 `.git`，初始化并提交：

```bash
git init -b main
git add .
git commit -m "Organize v1.6 research code for GitHub and Codex"
```

推送会触发 CPU CI。GitHub Actions 的线上状态和 Codex Cloud 发布结果必须分别查看；本地测试通过不代表这两个账号操作已完成。
