#!/usr/bin/env python3
"""Same checkpoint/data CPU-CUDA inference parity and batched latency.

This microbenchmark is separate from end-to-end planning latency.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from floor_tase.surrogate import Surrogate

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',type=Path,required=True)
    p.add_argument('--data',type=Path,required=True);p.add_argument('--device',default='cuda')
    p.add_argument('--out',type=Path,required=True);p.add_argument('--repeats',type=int,default=30)
    a=p.parse_args();sha=hashlib.sha256(a.model.read_bytes()).hexdigest()
    cpu=Surrogate(a.model,sha,'cpu');other=Surrogate(a.model,sha,a.device)
    with np.load(a.data,allow_pickle=False) as z: X=z['X']
    rows=[]
    for batch in (16,256,4096):
        x=X[np.arange(batch)%len(X)]
        left=np.array(cpu.predict(x));right=np.array(other.predict(x))
        equal=np.allclose(left,right,rtol=1e-4,atol=1e-5)
        if not equal: raise RuntimeError('CPU/device numerical parity failed')
        row={'batch':batch,'max_absolute_difference':float(abs(left-right).max())}
        for label,model in [('cpu',cpu),('device',other)]:
            for _ in range(3): model.predict(x)
            start=time.perf_counter()
            for _ in range(a.repeats): model.predict(x)
            row[label+'_wall_ms']=1000*(time.perf_counter()-start)/a.repeats
        rows.append(row)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps({'device':a.device,'model_sha256':sha,'rows':rows,
        'includes_host_transfer':True,'is_end_to_end_speedup':False},indent=2)+'\n')
    print(a.out.read_text())
