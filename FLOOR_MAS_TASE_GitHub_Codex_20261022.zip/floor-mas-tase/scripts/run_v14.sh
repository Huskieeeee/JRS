#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
stage="${1:-smoke}"
workers="${2:-4}"
case "$stage" in
  smoke|probe|collect|main|ood) config="configs/evidence_${stage}.json" ;;
  factorial) config="configs/evidence_score_factorial.json" ;;
  budget_s2|budget_s4|budget_s8) config="configs/evidence_${stage}.json" ;;
  *) echo "stage: smoke|probe|factorial|collect|main|ood|budget_s2|budget_s4|budget_s8" >&2; exit 2 ;;
esac
python -u scripts/run_handoff_round.py --config "$config" --out "results/server_v14_${stage}" --workers "$workers"
python scripts/summarize_handoff.py --run "results/server_v14_${stage}" --out "analysis/server_v14_${stage}"
python scripts/report_joint.py --run "results/server_v14_${stage}" --analysis "analysis/server_v14_${stage}"
