#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/../.."
if [[ $# != 1 || "$1" != */* ]]; then
  echo 'Usage: bash scripts/dev/publish_github.sh OWNER/floor-mas-tase' >&2
  exit 2
fi
command -v gh >/dev/null || { echo 'Install GitHub CLI and run gh auth login first.' >&2; exit 2; }
gh auth status
git rev-parse --verify HEAD >/dev/null
if [[ -n "$(git status --porcelain)" ]]; then
  echo 'Commit or review local changes before publishing.' >&2
  exit 2
fi
if git remote get-url origin >/dev/null 2>&1; then
  echo 'An origin remote already exists; inspect it and push with git.' >&2
  exit 2
fi
gh repo create "$1" --private --source . --remote origin --push
