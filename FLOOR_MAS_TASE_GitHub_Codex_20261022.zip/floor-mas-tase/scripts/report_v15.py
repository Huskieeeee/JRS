#!/usr/bin/env python3
"""Combine end-to-end efficacy, GPU execution evidence, and latency accounting."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from summarize_handoff import summarize,LABELS
from report_joint import report


def build(run,out):
    summarize(run,out);report(run,out)
    groups={}
    for p in sorted((run/'jobs').glob('*/result.json')):
        r=json.loads(p.read_text());j=r['job'];d=json.loads((p.parent/'decisions.json').read_text())
        g=groups.setdefault((j['condition'],j['method']),[]);g.append((r,d))
    rows=[]
    for (condition,method),items in groups.items():
        decisions=[d for _,ds in items for d in ds]
        models=[r['planner'].get('model',{}) for r,_ in items]
        row={'condition':condition,'method':method,'episodes':len(items),
             'completion':sum(r['metrics']['quality_success'] for r,_ in items),
             'J':float(np.mean([r['metrics']['J'] for r,_ in items])),
             'planning_wall_mean':float(np.mean([r['planner_wall_seconds'] for r,_ in items])),
             'initialization_wall_mean':float(np.mean([r['planner_initialization_wall_seconds'] for r,_ in items])),
             'total_episode_wall_mean':float(np.mean([r['wall_seconds'] for r,_ in items])),
             'decision_wall_p95':float(np.quantile([d['wall_seconds'] for d in decisions],.95)),
             'model_batches':sum(r['planner'].get('model_batches',0) for r,_ in items),
             'gpu_batches':sum(d['diagnostics'].get('model_evaluated',False) and d['diagnostics'].get('device','').startswith('cuda') for d in decisions),
             'phase_steps':sum(r['planner'].get('phase_steps',0) for r,_ in items),
             'interventions':sum(r['planner'].get('interventions',0) for r,_ in items),
             'devices':','.join(sorted({m.get('device','cpu') for m in models})),
             'gpu_names':','.join(sorted({m.get('gpu','') for m in models if m.get('gpu')}))}
        if method.startswith('jrs_release') and row['devices'].startswith('cuda') and row['gpu_batches']==0:
            raise ValueError('CUDA campaign has no GPU inference calls')
        rows.append(row)
    with (out/'v15_compute.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    lines=['# v1.5 主实验读数','','| 条件 | 方法 | 合格完成 | J↓ | 规划墙钟秒/回合↓ | 初始化秒/回合 | 决策P95秒 | GPU批次 |',
           '|---|---|---:|---:|---:|---:|---:|---:|']
    for r in rows:
        lines.append(f"|{r['condition']}|{LABELS.get(r['method'],r['method'])}|{r['completion']}/{r['episodes']}|{r['J']:.4f}|{r['planning_wall_mean']:.4f}|{r['initialization_wall_mean']:.4f}|{r['decision_wall_p95']:.4f}|{r['gpu_batches']}|")
    lines+=['','GPU 批次仅统计实际模型前向调用。物理事件环境和工程基线在 CPU 执行；两者共享质量门槛。',
            '规划墙钟含模型推理、数据传输和候选生成；模型初始化单独列出，总回合墙钟另见 CSV。',
            '全部配对区间与多重比较结果见 ALL_BASELINES_ZH.md；失败回合保留。']
    (out/'READOUT_ZH.md').write_text('\n'.join(lines)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();build(a.run,a.out)
