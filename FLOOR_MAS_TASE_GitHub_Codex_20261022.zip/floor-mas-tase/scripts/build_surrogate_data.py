#!/usr/bin/env python3
"""Extract public features and synthetic rollout labels; group by base world."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from floor_tase.surrogate import FEATURE_SCHEMA


def build(run, out):
    protocol = json.loads((run/'protocol.json').read_text())
    completion = json.loads((run/'COMPLETION.json').read_text())
    if not completion['data_complete']:
        raise ValueError('Collection campaign must be complete')
    X,y,worlds,groups = [],[],[],[]
    target = None
    for f in sorted((run/'jobs').glob('*/result.json')):
        r = json.loads(f.read_text())
        if r['job']['method'] != 'jrs_evidence':
            continue
        decisions = f.parent/'decisions.json'
        # Runner result hashes also cover decisions; enforce before training.
        from run_repair_round import audit_saved
        audit_saved(f.parent,r['job'])
        for d in json.loads(decisions.read_text()):
            diag = d['diagnostics']
            if diag.get('screening') is not None:
                raise ValueError('Use exhaustive teacher runs for collection')
            if target is None: target = diag['target_protocol']
            if diag['target_protocol'] != target:
                raise ValueError('Mixed label protocols')
            world = f"{protocol['split']}:{r['job']['world_id']}"
            group = f"{world}:{r['job']['condition']}:{r['job']['planner_replicate']}:{d['index']}"
            for p in diag['predictions']:
                X.append(p['features']); y.append([-p['score'][0],p['score'][1]])
                worlds.append(world); groups.append(group)
    if not X: raise ValueError('No exhaustive v1.4 labels found')
    meta = {'feature_schema':FEATURE_SCHEMA,'target_protocol':target,
            'source_freeze_sha256':hashlib.sha256((run/'FREEZE.json').read_bytes()).hexdigest(),
            'label_source':'synthetic_public_belief_continuation_only',
            'rows':len(X),'worlds':len(set(worlds))}
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('wb') as f:
        np.savez_compressed(f,X=np.asarray(X,dtype=np.float32),y=np.asarray(y,dtype=np.float32),
                            worlds=np.asarray(worlds),groups=np.asarray(groups),metadata=json.dumps(meta))
    print(json.dumps(meta))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();build(a.run,a.out)
