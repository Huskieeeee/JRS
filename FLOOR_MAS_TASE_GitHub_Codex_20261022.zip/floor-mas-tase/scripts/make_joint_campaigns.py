#!/usr/bin/env python3
"""Generate declared, paired research campaigns; never launches experiments."""
from copy import deepcopy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def generate():
    template = json.loads((ROOT/'configs/adaptive_pilot.json').read_text())
    template['primary_method'] = 'jrs_joint'
    template['planning_budget'].update(joint_candidates=8,joint_samples=4,
        joint_tail_weight=.25,joint_collateral_margin=.10,joint_failure_margin=.05)
    template['claims'] = 'Development/held-out simulation evaluation; no superiority inferred before analysis.'
    template['snapshot_decisions'] = [0,5,15]
    main = ['jrs_joint','fixed_jrs','fixed_random','certificate_window','handoff',
            'handoff_optimistic','handoff_adaptive','arch_staged','arch_dispatch']
    key = {'base','failure_high','budget_short','freshness_short','deadline_tight'}
    rows = []
    def save(name, start, per_layout, methods, conditions=None, changes=None, split=None):
        c = deepcopy(template)
        c.update(split=split or name, world_start=start, worlds_per_layout=per_layout,methods=methods)
        if conditions is not None: c['conditions'] = deepcopy(conditions)
        if changes: c['base_scenario'].update(changes)
        path = ROOT/'configs'/f'{name}.json'
        path.write_text(json.dumps(c,indent=2)+'\n')
        rows.append({'name':name,'worlds':3*per_layout,'conditions':len(c['conditions']),
                     'methods':len(methods),'episodes':3*per_layout*len(c['conditions'])*len(methods),
                     'world_split':c['split'],'world_start':start})
        return c, path
    smoke = [c for c in template['conditions'] if c['id'] in ('base','collateral_off')]
    save('joint_smoke',9700000,1,['jrs_joint','fixed_jrs','fixed_random','handoff_adaptive','arch_staged','arch_dispatch'],smoke)
    probe = [c for c in template['conditions'] if c['id'] in ('base','failure_high','deadline_tight')]
    save('joint_model_probe',9790000,2,['jrs_joint','jrs_joint_central','jrs_joint_no_tail',
        'fixed_jrs','fixed_random','handoff_adaptive'],probe)
    save('joint_pilot',9710000,2,main)
    save('joint_main',9720000,20,main)
    mechanisms = [c for c in template['conditions'] if c['id'] in key]
    save('joint_ablation',9730000,20,['jrs_joint','jrs_joint_no_provider','jrs_joint_local_scope',
        'jrs_joint_no_diagnostic','jrs_joint_global_wait','jrs_joint_central','jrs_joint_no_tail'],mechanisms)
    robust = [
        {'id':'matched','changes':{}},
        {'id':'collateral_under','changes':{'collateral_probability':.35}},
        {'id':'collateral_over','changes':{'collateral_probability':.05}},
        {'id':'failure_under','changes':{'repair_failure_prob':.15}},
        {'id':'combined_shift','changes':{'collateral_probability':.35,'repair_failure_prob':.15,'freshness':18}},
        {'id':'short_budget_shift','changes':{'horizon':60,'collateral_probability':.35}}]
    controls = ['jrs_joint','fixed_jrs','fixed_random','handoff_adaptive','jrs_joint_central']
    save('joint_robustness',9740000,20,controls,robust)
    save('joint_transfer',9750000,20,['jrs_joint','fixed_jrs','jrs_joint_dispatch','arch_dispatch',
        'jrs_joint_dispatch_continuation'],mechanisms)
    for n in (12,24,48):
        save(f'joint_scale{n}',9760000+n*100,10,controls,smoke,
             {'n_cells':n,'n_regions':max(3,n//4),'horizon':100*n/12,'freshness':60*n/12})
    save('joint_ood_combo',9770000,10,controls,smoke,
         {'n_cells':24,'n_regions':6,'horizon':160,'freshness':30,
          'repair_fraction':.6,'repair_overlap':.8,'measurement_delay':3.,'robots_per_skill':2})
    for multiplier in (1,2,4):
        c,path = save(f'joint_budget{multiplier}',9780000,10,
            ['jrs_joint','fixed_jrs','fixed_random','certificate_window','handoff_adaptive'],mechanisms,
            split='joint_budget_shared')
        b=c['planning_budget']; b.update(joint_samples=2*multiplier,
            max_candidates=8*multiplier,cover_nodes=500*multiplier,window_nodes=1500*multiplier,
            adaptive_min_samples=multiplier,adaptive_max_samples=2*multiplier)
        path.write_text(json.dumps(c,indent=2)+'\n')
    # Untouched until algorithm choices and external adapters are finalized.
    c,path=save('joint_holdout',9900000,50,main)
    c['claims']='Held-out simulation test. Run once after fixing algorithm and analysis. Not physical or author-baseline validation.'
    c['research_role']='heldout_simulation'
    path.write_text(json.dumps(c,indent=2)+'\n')
    (ROOT/'configs/JOINT_CAMPAIGNS.json').write_text(json.dumps(rows,indent=2)+'\n')
    for row in rows: print(row['name'],row['episodes'],'episodes;',row['worlds'],'physical worlds')


if __name__=='__main__': generate()
