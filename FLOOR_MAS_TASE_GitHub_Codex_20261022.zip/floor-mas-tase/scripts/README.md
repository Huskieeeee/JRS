# Script entry points

The primary v1.6 workflow is `run_v16.sh` / `run_v16_multi.sh`. Python implementations for prepare, run, analysis, report, plot, benchmark, merge, budget, and GPU checks now live in `src/floor_tase/experiments/`; the original script names remain compatibility wrappers.

`run_handoff_round.py` delegates to the shared runner. v1.4/v1.5 scripts and model-training tools remain available for historical comparisons; several expect old configs not included in this v1.6 archive. Use the v1.6 entry points for the current project.

`dev/setup.sh` installs the CPU editable package. `dev/check.sh` runs the current developer checks. `dev/publish_github.sh` publishes a locally committed checkout to a new private repository using an authenticated GitHub CLI.
