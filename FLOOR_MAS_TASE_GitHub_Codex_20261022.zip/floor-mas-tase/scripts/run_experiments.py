#!/usr/bin/env python3
"""Strict, paired, resumable runner. A recorded pre-run receipt is not a registration."""
from __future__ import annotations
import argparse, dataclasses, hashlib, itertools, json, os, pathlib, platform, sys, time, traceback
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

def utc():
    return datetime.now(timezone.utc).isoformat()

def digest_bytes(value):
    return hashlib.sha256(value).hexdigest()

def stable_seed(namespace, *parts):
    payload = json.dumps([namespace, *parts], separators=(',', ':'), sort_keys=True).encode()
    return int.from_bytes(hashlib.blake2b(payload, digest_size=8).digest(), 'little') % (2**31 - 1)

def read_json(path):
    return json.loads(pathlib.Path(path).read_text())

def write_json(path, value):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    temp.replace(path)

def source_identity():
    paths = sorted((ROOT / 'src').rglob('*.py')) + [pathlib.Path(__file__).resolve()]
    hashes = {str(p.relative_to(ROOT)): digest_bytes(p.read_bytes()) for p in paths}
    return {'files': hashes, 'sha256': digest_bytes(json.dumps(hashes, sort_keys=True).encode())}

def jobs_for(config):
    base = config.get('base_scenario', {})
    n = int(config.get('world_replicates', 1))
    start = int(config['world_start'])
    offset = 0
    for condition in config['conditions']:
        for rep in range(n):
            world_id = start + offset
            offset += 1
            scenario = dict(base, **condition.get('scenario', {}))
            # Separate streams; no method name participates in physical/sensor seeds.
            scenario_seed = stable_seed('scenario', config['split'], world_id)
            measurement_seed = stable_seed('measurement', config['split'], world_id)
            for method in config['methods']:
                for planner_rep in range(int(config.get('planner_replicates', 1))):
                    job_id = f"{condition['id']}__w{world_id}__{method}__p{planner_rep}"
                    yield {'job_id': job_id, 'condition': condition['id'], 'world_id': world_id,
                           'replicate': rep, 'scenario': scenario, 'method': method,
                           'scenario_seed': scenario_seed, 'measurement_seed': measurement_seed,
                           'planner_seed': stable_seed('planner', config['split'], world_id, planner_rep),
                           'planner_replicate': planner_rep}

def receipt_for(config_path, config):
    jobs = list(jobs_for(config))
    return {'schema': 'floor-tase-experiment-1', 'created_utc': utc(),
            'config_sha256': digest_bytes(pathlib.Path(config_path).read_bytes()),
            'source': source_identity(), 'split': config['split'],
            'n_jobs': len(jobs), 'n_worlds': len({x['world_id'] for x in jobs}),
            'job_identity_sha256': digest_bytes(json.dumps(jobs, sort_keys=True).encode()),
            'training_jobs': 0, 'python': platform.python_version(), 'platform': platform.platform(),
            'notes': 'Local pre-run freeze; not a third-party preregistration or proof of execution.'}

def assert_receipt_matches(old, new):
    for key in ('config_sha256', 'split', 'n_jobs', 'n_worlds', 'job_identity_sha256'):
        if old.get(key) != new.get(key):
            raise RuntimeError(f'Resume identity mismatch: {key}; use a NEW output directory.')
    if old['source']['sha256'] != new['source']['sha256']:
        raise RuntimeError('Runtime source changed after freeze; use a NEW output directory.')

def initialize(config_path, config, out, require_existing=False):
    expected = receipt_for(config_path, config)
    receipt_path = out / 'FREEZE.json'
    if receipt_path.exists():
        assert_receipt_matches(read_json(receipt_path), expected)
    else:
        if require_existing:
            raise RuntimeError('Confirmatory execution requires --freeze-only first and a reviewed FREEZE.json.')
        out.mkdir(parents=True, exist_ok=True)
        if any(out.iterdir()):
            raise RuntimeError('Output folder is nonempty without a freeze receipt.')
        write_json(receipt_path, expected)
        (out / 'protocol.json').write_bytes(pathlib.Path(config_path).read_bytes())
        for relative in expected['source']['files']:
            dst = out / 'runtime_snapshot' / relative
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes((ROOT / relative).read_bytes())
    return read_json(receipt_path)

def json_safe(value):
    if dataclasses.is_dataclass(value):
        return json_safe(dataclasses.asdict(value))
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [json_safe(v) for v in value]
    if hasattr(value, 'item'):
        return value.item()
    return value

def static_reference(observation):
    """A deliberately narrower oracle, NOT the optimum of the parallel simulator."""
    from floor_tase.bounds import StaticRepair, StaticView, StaticSuccessor, solve_static_serial
    defects = frozenset(c for j in observation.jobs if j.status == 'pending' for c in j.targets)
    certified = frozenset(c.id for c in observation.cells if c.certified)
    repairs = []
    for j in observation.jobs:
        if j.status != 'pending':
            continue
        repairs.append(StaticRepair(j.id + ':local', frozenset(j.targets) & defects, frozenset(j.local_impact), j.duration))
        repairs.append(StaticRepair(j.id + ':expanded', frozenset(j.expanded_targets) & defects, frozenset(j.expanded_impact), j.expanded_duration))
    views = [StaticView(v.id, frozenset(v.covers), v.duration) for v in observation.views]
    tasks = [StaticSuccessor(t.id, frozenset(t.requires), t.duration, t.deadline) for t in observation.tasks]
    value = dataclasses.asdict(solve_static_serial(defects, certified, repairs, views, tasks,
                  horizon=observation.horizon, time_limit_s=1., max_nodes=100000))
    # JSON has no infinity; retain the exact status so null never means infeasible.
    for field in ('completion_time', 'lower_bound'):
        if not __import__('math').isfinite(value[field]):
            value[field] = None
    value['parallel_environment_optimality_claim'] = False
    value['omitted_from_surrogate'] = ['travel', 'parallel_resources', 'measurement_noise', 'stochastic_collateral_damage', 'delayed_packets']
    return value

def run_job(job, config, job_dir):
    from floor_tase.model import ScenarioConfig, make_scenario
    from floor_tase.environment import RecoveryEnv
    from floor_tase.planners import make_planner
    kwargs = dict(job['scenario'])
    kwargs.update(config.get('method_scenario_overrides', {}).get(job['method'], {}))
    permitted = {'evidence_policy', 'assumed_radius'}
    if set(config.get('method_scenario_overrides', {}).get(job['method'], {})) - permitted:
        raise ValueError('Method overrides cannot change the physical world, noise, tasks, or budgets.')
    scenario_config = ScenarioConfig(**kwargs)
    scenario = make_scenario(job['scenario_seed'], scenario_config, measurement_seed=job['measurement_seed'])
    env = RecoveryEnv(scenario)
    oracle = static_reference(env.observe()) if config['split'] == 'exact' and job['method'] == config['methods'][0] else None
    planner = make_planner(job['method'], seed=job['planner_seed'], time_limit_s=float(config.get('planner_time_limit_s', .05)))
    started = time.perf_counter()
    decision_records = []
    max_decisions = int(config.get('max_decisions', 20000))
    while not env.done:
        if len(decision_records) >= max_decisions:
            raise RuntimeError('Runner decision guard hit (not counted as physical infeasibility).')
        before = env.observe()
        actions = tuple(planner.select(before, env.allowed_actions()))
        decision_records.append({'index': len(decision_records), 'actions': json_safe(actions)})
        if actions:
            env.step_joint(actions)
        else:
            env.advance()
    result = json_safe(env.result())
    trace = json_safe(env.get_trace())
    trace_path = job_dir / 'trajectory.jsonl'
    with trace_path.open('w') as stream:
        stream.write(json.dumps({'record_type': 'metadata', **job}, sort_keys=True) + '\n')
        for event in trace:
            stream.write(json.dumps({'record_type': 'event', **event}, sort_keys=True) + '\n')
    write_json(job_dir / 'decisions.json', decision_records)
    write_json(job_dir / 'scenario.json', json_safe(scenario))
    if oracle is not None:
        write_json(job_dir / 'static_reference.json', oracle)
    return {'job': job, 'status': 'complete', 'finished_utc': utc(), 'metrics': result,
            'planner': json_safe(planner.diagnostics()), 'wall_seconds': time.perf_counter() - started,
            'trajectory_sha256': digest_bytes(trace_path.read_bytes()), 'decision_count': len(decision_records)}

def run(config_path, out, freeze_only=False, max_jobs=None):
    config = read_json(config_path)
    if config.get('training_jobs', 0) != 0:
        raise ValueError('This release implements planning, not a learned-policy training experiment.')
    formal = config['split'] in ('confirmation', 'robustness', 'scale', 'exact')
    if formal or config.get('formal', False):
        raise RuntimeError('Legacy formal entrypoint disabled on modified repair-round source. Use run_repair_round.py and its author/physical/protocol gates; original frozen results remain historical.')
    receipt = initialize(config_path, config, out, require_existing=formal and not freeze_only)
    if freeze_only:
        print(json.dumps({'status': 'frozen_not_run', 'receipt': str(out / 'FREEZE.json'),
                          'n_jobs': receipt['n_jobs'], 'n_worlds': receipt['n_worlds']}), flush=True)
        return 0
    jobs = list(jobs_for(config))
    done = errors = executed = 0
    run_start = utc()
    for job in jobs:
        job_dir = out / 'jobs' / job['job_id']
        saved = job_dir / 'result.json'
        if saved.exists():
            record = read_json(saved)
            if record.get('job') != job:
                raise RuntimeError(f"Saved job identity mismatch: {job['job_id']}")
            if record['status'] == 'complete':
                if digest_bytes((job_dir / 'trajectory.jsonl').read_bytes()) != record['trajectory_sha256']:
                    raise RuntimeError(f"Trajectory digest mismatch: {job['job_id']}")
                done += 1
            else:
                errors += 1
            continue
        if max_jobs is not None and executed >= max_jobs:
            break
        job_dir.mkdir(parents=True, exist_ok=True)
        try:
            record = run_job(job, config, job_dir)
            done += 1
        except Exception as exc:
            errors += 1
            record = {'job': job, 'status': 'execution_error', 'error': str(exc), 'traceback': traceback.format_exc(), 'finished_utc': utc()}
        write_json(saved, record)
        executed += 1
        print(json.dumps({'job': job['job_id'], 'status': record['status'], 'completed': done, 'errors': errors,
                          'planned': len(jobs)}), flush=True)
        if errors and config.get('stop_on_error', True):
            break
    complete = done + errors == len(jobs)
    write_json(out / 'COMPLETION.json', {'started_utc': run_start, 'updated_utc': utc(), 'expected_jobs': len(jobs),
               'completed_jobs': done, 'execution_errors': errors, 'all_records_present': complete,
               'data_complete': complete and errors == 0, 'training_jobs': 0,
               'performance_superiority': 'not determined by completeness'})
    return 0 if complete and errors == 0 else 2

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--freeze-only', action='store_true')
    parser.add_argument('--max-jobs', type=int, help='Explicitly partial execution; returns 2 until complete.')
    args = parser.parse_args()
    raise SystemExit(run(pathlib.Path(args.config), pathlib.Path(args.out), args.freeze_only, args.max_jobs))
