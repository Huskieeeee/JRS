#!/usr/bin/env python3
"""Verify frozen CPU/CUDA score parity and measure matched inference batches."""
import argparse,hashlib,json,sys,time
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from floor_tase.ensemble import ReturnEnsemble

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model',type=Path,default=Path('models/v15_ensemble_cpu.npz'))
    p.add_argument('--data',type=Path,default=Path('datasets/v14_teacher.npz'))
    p.add_argument('--device',default='cuda');p.add_argument('--out',type=Path,default=Path('analysis/v15_gpu_benchmark.json'))
    a=p.parse_args();sha=hashlib.sha256(a.model.read_bytes()).hexdigest()
    cpu=ReturnEnsemble(a.model,sha,'cpu');gpu=ReturnEnsemble(a.model,sha,a.device)
    with np.load(a.data,allow_pickle=False) as z:X=z['X']
    rows=[]
    for batch in (16,256,4096):
        x=X[np.arange(batch)%len(X)];c=cpu.predict(x);g=gpu.predict(x)
        np.testing.assert_allclose(g,c,rtol=1e-4,atol=2e-5)
        row={'batch':batch,'max_difference':float(abs(c-g).max())}
        for label,model in [('cpu',cpu),('device',gpu)]:
            for _ in range(5):model.predict(x)
            start=time.perf_counter()
            for _ in range(50):model.predict(x)
            row[label+'_wall_ms']=(time.perf_counter()-start)*1000/50
        rows.append(row)
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps({'runtime':gpu.runtime_info(),'rows':rows,'includes_transfers':True},indent=2)+'\n')
    print(a.out.read_text())
