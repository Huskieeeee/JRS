#!/usr/bin/env python3
"""World-paired exploratory/confirmatory summaries; failed executions are never discarded."""
from __future__ import annotations
import argparse, collections, csv, json, math, pathlib, sys
import numpy as np
from scipy.stats import binomtest, beta

def read(path):
    return json.loads(pathlib.Path(path).read_text())

def save(path, value):
    pathlib.Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')

def holm(p_values):
    order = sorted(range(len(p_values)), key=lambda i: p_values[i])
    adjusted = [1.] * len(p_values)
    last = 0.
    for rank, index in enumerate(order):
        last = max(last, (len(order) - rank) * p_values[index])
        adjusted[index] = min(1., last)
    return adjusted

def paired_bootstrap(diff, rng, repeats=10000):
    values = np.asarray(diff, dtype=float)
    if not len(values):
        return [None, None]
    means = []
    for start in range(0, repeats, 1000):
        indices = rng.integers(0, len(values), size=(min(1000, repeats - start), len(values)))
        means.extend(values[indices].mean(axis=1).tolist())
    return np.quantile(means, [.025, .975]).tolist()

def sign_flip(diff, rng, repeats=20000):
    values = np.asarray(diff, dtype=float)
    if not len(values) or np.all(values == 0):
        return 1.
    observed = abs(values.mean())
    count = 0
    for start in range(0, repeats, 1000):
        signs = rng.choice([-1., 1.], size=(min(1000, repeats - start), len(values)))
        count += int(np.sum(abs((signs * values).mean(axis=1)) >= observed - 1e-12))
    return (count + 1.) / (repeats + 1.)

def get_metric(metrics, names, default=None):
    for name in names:
        if name in metrics:
            return metrics[name]
    return default

def normalized_metrics(record):
    raw = record['metrics']
    false = get_metric(raw, ['false_releases', 'false_release_count'])
    complete = get_metric(raw, ['success', 'all_completed', 'complete'])
    cost = get_metric(raw, ['cost', 'J'])
    if false is None or complete is None or cost is None:
        raise ValueError('Missing false_releases/success/cost: cannot infer quality success from a missing field.')
    qualified = int(bool(get_metric(raw, ['qualified_completion', 'quality_success'], bool(complete) and int(false) == 0)))
    result = {'qualified_completion': qualified, 'false_release_episode': int(int(false) > 0),
              'unsafe_release_episode': int(int(false) > 0),
              'false_releases': int(false), 'physical_completion': int(bool(complete)), 'cost': float(cost)}
    names = {
        'inspections': ['inspections', 'inspection_count'],
        'repairs': ['repairs', 'repair_count'],
        'stale_reuse': ['stale_authorizations', 'stale_reuse', 'stale_reuses'],
        'quality_false_releases': ['quality_false_releases'],
        'duplicate_inspections': ['duplicate_inspections', 'duplicate_checks'],
        'invalidated_measurements': ['invalidated_evidence', 'invalidated_measurements'],
        'preserved_evidence': ['preserved_evidence'],
        'repeated_invalidations': ['repeated_invalidations'],
        'successor_revocations': ['successor_revocations'],
        'stale_packets_rejected': ['stale_packets_rejected'],
        'repair_cap_exhaustions': ['repair_cap_exhaustions'],
        'deadline_misses': ['deadline_misses'],
        'time': ['time', 'makespan'],
        'charged_time': ['charged_time'],
        'completed_tasks': ['completed_tasks'],
        'qualified_tasks': ['qualified_tasks'],
        'total_tasks': ['total_tasks'],
        'waiting_time': ['waiting_time', 'wait_time'],
        'travel_distance': ['travel_distance', 'travel'],
        'authorized_tasks': ['authorizations', 'authorized_tasks', 'releases'],
        'timeouts': ['timeouts', 'timeout'],
    }
    for dst, alternatives in names.items():
        value = get_metric(raw, alternatives)
        if value is not None:
            result[dst] = float(value)
    if 'quality_false_releases' in result:
        result['quality_false_release_episode'] = int(result['quality_false_releases'] > 0)
    if 'unfinished_fraction' in raw:
        result['unfinished_fraction'] = float(raw['unfinished_fraction'])
    elif result.get('total_tasks', 0):
        result['unfinished_fraction'] = 1 - result.get('qualified_tasks', result['completed_tasks']) / result['total_tasks']
    diag = record.get('planner', {})
    result['planner_wall_seconds'] = float(diag.get('total_wall_s', 0))
    result['planner_search_nodes'] = float(diag.get('search_nodes', 0))
    return result

def aggregate_worlds(records):
    # Planner replicates are averaged INSIDE a physical world; never treated as fresh worlds.
    groups = collections.defaultdict(list)
    for record in records:
        job = record['job']
        groups[(job['method'], job['world_id'])].append(normalized_metrics(record))
    values = {}
    for key, rows in groups.items():
        common = set.intersection(*(set(r) for r in rows))
        values[key] = {m: float(np.mean([r[m] for r in rows])) for m in common}
    return values

def analyze(run_dir, bootstrap=10000):
    protocol = read(run_dir / 'protocol.json')
    receipt = read(run_dir / 'FREEZE.json')
    records = [read(p) for p in sorted((run_dir / 'jobs').glob('*/result.json'))]
    errors = [r for r in records if r['status'] != 'complete']
    complete_records = [r for r in records if r['status'] == 'complete']
    audit_failures = [r['job']['job_id'] for r in complete_records if r.get('metrics', {}).get('audit', {}).get('pass') is not True]
    seen = [r['job']['job_id'] for r in records]
    if len(seen) != len(set(seen)):
        raise ValueError('Duplicate job IDs in record archive.')
    complete = len(records) == receipt['n_jobs'] and not errors and not audit_failures
    output = run_dir / 'analysis'
    output.mkdir(exist_ok=True)
    save(output / 'completeness.json', {'expected_jobs': receipt['n_jobs'], 'present_jobs': len(records),
         'complete_jobs': len(complete_records), 'execution_errors': len(errors), 'data_complete': complete,
         'error_job_ids': [r['job']['job_id'] for r in errors],
         'audit_failed_or_missing_job_ids': audit_failures,
         'inferential_tests_enabled': complete,
         'training_jobs': 0, 'phase': protocol['split']})
    # Even execution failures remain visible; inferential analysis is blocked rather than complete-case filtered.
    if not complete:
        print('Analysis blocked: incomplete run or execution errors. See analysis/completeness.json.')
        return 2
    world = aggregate_worlds(complete_records)
    summaries = []
    for method in protocol['methods']:
        rows = [r for (m, w), r in world.items() if m == method]
        fields = set.intersection(*(set(r) for r in rows))
        item = {'method': method, 'n_worlds': len(rows), 'n_episodes': sum(r['job']['method'] == method for r in complete_records)}
        item.update({k: float(np.mean([r[k] for r in rows])) for k in fields})
        # This is a world-level risk bound, never based on all release events as independent trials.
        failures = sum(r['false_release_episode'] > 0 for r in rows)
        item['worlds_with_any_false_release'] = failures
        item['false_release_one_sided_95_upper'] = float(beta.ppf(.95, failures + 1, len(rows) - failures)) if failures < len(rows) else 1.
        summaries.append(item)
    save(output / 'summary.json', summaries)
    condition_summaries = []
    condition_groups = collections.defaultdict(list)
    for record in complete_records:
        condition_groups[(record['job']['condition'], record['job']['method'])].append(record)
    for (condition, method), subset in sorted(condition_groups.items()):
        rows = list(aggregate_worlds(subset).values())
        fields = set.intersection(*(set(r) for r in rows))
        condition_summaries.append({'condition': condition, 'method': method, 'n_worlds': len(rows),
              **{k: float(np.mean([r[k] for r in rows])) for k in fields}})
    save(output / 'summary_by_condition.json', condition_summaries)
    with (output / 'summary_by_condition.csv').open('w') as f:
        columns = sorted(set().union(*(x.keys() for x in condition_summaries)))
        writer = csv.DictWriter(f, fieldnames=columns); writer.writeheader(); writer.writerows(condition_summaries)
    columns = sorted(set().union(*(x.keys() for x in summaries)))
    with (output / 'summary.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=['method'] + [x for x in columns if x != 'method'])
        writer.writeheader(); writer.writerows(summaries)
    episode_rows = []
    for record in complete_records:
        job = record['job']
        episode_rows.append({k: job[k] for k in ('job_id', 'method', 'world_id', 'condition', 'scenario_seed', 'measurement_seed', 'planner_seed')} | normalized_metrics(record))
    fields = sorted(set().union(*(x.keys() for x in episode_rows)))
    with (output / 'episodes.csv').open('w') as f:
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(episode_rows)
    rng = np.random.default_rng(20261011)
    proposed = protocol.get('proposed_method', 'jrs')
    contrasts = []
    for reference in protocol.get('primary_references', [m for m in protocol['methods'] if m != proposed]):
        pw = {w for (m, w) in world if m == proposed}
        rw = {w for (m, w) in world if m == reference}
        if pw != rw:
            raise ValueError(f'Unpaired world set for {reference}.')
        ids = sorted(pw)
        for metric in ('qualified_completion', 'cost'):
            a = np.array([world[(proposed, w)][metric] for w in ids])
            b = np.array([world[(reference, w)][metric] for w in ids])
            delta = a - b
            binary = metric == 'qualified_completion' and np.isin(a, [0, 1]).all() and np.isin(b, [0, 1]).all()
            gains = int(np.sum((a == 1) & (b == 0))) if binary else None
            losses = int(np.sum((a == 0) & (b == 1))) if binary else None
            p = float(binomtest(gains, gains + losses, .5).pvalue) if binary and gains + losses else (1. if binary else sign_flip(delta, rng))
            contrasts.append({'proposed': proposed, 'reference': reference, 'metric': metric,
                'n_worlds': len(ids), 'mean_paired_difference': float(delta.mean()),
                'paired_world_bootstrap_95_ci': paired_bootstrap(delta, rng, bootstrap),
                'p_raw': p, 'test': 'exact_discordant_pair_binomial' if binary else 'paired_world_sign_flip_20000',
                'gains': gains, 'losses': losses,
                'interpretation': 'exploratory development comparison' if protocol['split'] != 'confirmation' else 'frozen confirmatory comparison'})
    for contrast, adjusted in zip(contrasts, holm([r['p_raw'] for r in contrasts])):
        contrast['p_holm'] = adjusted
        contrast['family_size'] = len(contrasts)
    save(output / 'paired_contrasts.json', contrasts)
    save(output / 'analysis_receipt.json', {'config_sha256': receipt['config_sha256'], 'runtime_source_sha256': receipt['source']['sha256'],
        'n_worlds': receipt['n_worlds'], 'n_episodes': len(records), 'bootstrap_resamples': bootstrap,
        'bootstrap_unit': 'physical world; all methods and planner replicates stay within the world',
        'holm_family': 'two-sided qualified-completion and cost tests across every preregistered primary reference',
        'scope': 'No policy training. Completion gate does not establish performance superiority.',
        'risk_semantics': 'false_releases / unsafe_release includes stale evidence OR physical bad quality; quality_false_releases is physical bad quality only.',
        'missing_metric_policy': 'Missing optional fields remain missing, never imputed as zero.'})
    print(json.dumps({'analysis': str(output), 'n_episodes': len(records), 'n_worlds': receipt['n_worlds'], 'summary': summaries}, indent=2))
    return 0

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('run_dir', type=pathlib.Path)
    parser.add_argument('--bootstrap', type=int, default=10000)
    args = parser.parse_args()
    raise SystemExit(analyze(args.run_dir, args.bootstrap))
