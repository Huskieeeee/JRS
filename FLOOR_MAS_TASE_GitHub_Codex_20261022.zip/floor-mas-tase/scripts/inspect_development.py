#!/usr/bin/env python3
"""Inspect exported per-world development tables without re-running simulation."""
import argparse
import csv
import json
from pathlib import Path
from collections import Counter

def inspect(folder,out):
    report=json.loads((folder/'analysis.json').read_text())
    rows=list(csv.DictReader((folder/'episodes.csv').open()))
    keys=[(r['world_id'],r['condition'],r['method'],r['planner_replicate']) for r in rows]
    if len(set(keys))!=len(keys):raise ValueError('Duplicate experiment keys')
    counts=Counter((r['condition'],r['method']) for r in rows)
    if len(set(counts.values()))!=1:raise ValueError('Unequal method/condition counts')
    worlds={}
    for r in rows:worlds.setdefault(r['world_id'],set()).add(r['base_world_sha256'])
    if any(len(v)!=1 for v in worlds.values()):raise ValueError('World pairing mismatch')
    if len(rows)!=report['episodes'] or len(worlds)!=report['unique_worlds']:raise ValueError('Report volume mismatch')
    lines=['# 逐世界开发数据核对','',f"{len(rows)}条记录，{len(worlds)}个独立基础世界。主方法：{report.get('primary_method',report['comparisons'][0]['method'])}。",'',
           '核对导出表的唯一键、各条件方法计数与基础世界身份。此导出包不含全部原始轨迹，完整事件审计状态来自原运行回执。','',
           '| 指标 | 总计 |','|---|---:|']
    for k in ('false_releases','quality_false_releases','stale_authorizations'):
        lines.append(f"| {k} | {sum(float(r[k]) for r in rows):g} |")
    lines+=['','## 配对机制比较','',
            '| 条件 | 对照 | 完成胜/负世界 | 完成差 | 完成Holm p | J差 | J Holm p |',
            '|---|---|---:|---:|---:|---:|---:|']
    for c in report['comparisons']:
        lines.append(f"| {c['condition']} | {c['control']} | {c['completion_gains']}/{c['completion_losses']} | "
                     f"{100*c['completion_difference']:.2f}百分点 | {c['completion_holm_p_exploratory']:.5f} | "
                     f"{c['J_difference']:.4f} | {c['J_holm_p_exploratory']:.5f} |")
    lines+=['','条件与方法重复不能作为额外独立世界。原报告的Holm校正分别覆盖全部方法×条件的完成检验和成本检验。',
            '开发集已用于下一版设计，不作为新算法的独立确认集。','']
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text('\n'.join(lines))
    print(json.dumps({'rows':len(rows),'worlds':len(worlds),'out':str(out)}))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--analysis-dir',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    args=p.parse_args();inspect(args.analysis_dir,args.out)
