#!/usr/bin/env python3
"""Train the same batched MLP on CPU or CUDA; export portable non-pickle weights."""
import argparse
import hashlib
import json
from pathlib import Path
import time
import numpy as np


def split_worlds(worlds, seed, fraction=.2):
    unique = sorted(set(worlds),key=lambda w:hashlib.sha256(f'{seed}:{w}'.encode()).hexdigest())
    if len(unique)<3: raise ValueError('Need at least three independent worlds')
    n=max(1,min(len(unique)-1,round(len(unique)*fraction)))
    return unique[n:],unique[:n]


def train(a):
    import torch
    if a.device != 'cpu' and not torch.cuda.is_available():
        raise RuntimeError('CUDA requested but unavailable')
    if min(a.epochs,a.batch_size,a.hidden)<1: raise ValueError('Positive training budgets required')
    torch.manual_seed(a.seed)
    if a.device.startswith('cuda'): torch.cuda.manual_seed_all(a.seed)
    torch.set_num_threads(a.threads)
    torch.use_deterministic_algorithms(True)
    started=time.perf_counter()
    with np.load(a.data,allow_pickle=False) as z:
        X,y,worlds,groups=z['X'],z['y'],z['worlds'],z['groups']
        meta=json.loads(str(z['metadata']))
    training,validation=split_worlds(worlds.tolist(),getattr(a,'split_seed',None) or a.seed)
    tr=np.isin(worlds,training); va=~tr
    mean=X[tr].mean(0);scale=np.maximum(X[tr].std(0),1e-4)
    x=torch.as_tensor((X-mean)/scale)
    target=torch.as_tensor(np.column_stack((y[:,0],y[:,1]/5.)))
    model=torch.nn.Sequential(torch.nn.Linear(X.shape[1],a.hidden),torch.nn.ReLU(),
        torch.nn.Linear(a.hidden,a.hidden),torch.nn.ReLU(),torch.nn.Linear(a.hidden,2)).to(a.device)
    opt=torch.optim.Adam(model.parameters(),lr=a.lr)
    indices=np.flatnonzero(tr);valindices=np.flatnonzero(va)
    rng=np.random.default_rng(a.seed);history=[];best=None;bestloss=float('inf');bestepoch=0
    def loss(pred,truth):
        return torch.nn.functional.binary_cross_entropy_with_logits(pred[:,0],truth[:,0])+torch.nn.functional.mse_loss(pred[:,1],truth[:,1])
    for epoch in range(a.epochs):
        model.train();rng.shuffle(indices)
        for start in range(0,len(indices),a.batch_size):
            idx=indices[start:start+a.batch_size]
            opt.zero_grad();value=loss(model(x[idx].to(a.device)),target[idx].to(a.device));value.backward();opt.step()
        model.eval()
        with torch.no_grad():
            v=0.
            for start in range(0,len(valindices),a.batch_size):
                idx=valindices[start:start+a.batch_size]
                v+=float(loss(model(x[idx].to(a.device)),target[idx].to(a.device)).item())*len(idx)/len(valindices)
        history.append(v)
        if v<bestloss:
            bestloss=v;bestepoch=epoch+1
            best={k:t.detach().cpu().clone() for k,t in model.state_dict().items()}
    model.load_state_dict(best)
    with torch.no_grad():
        pred=torch.cat([model(x[valindices[start:start+a.batch_size]].to(a.device)).cpu()
                        for start in range(0,len(valindices),a.batch_size)])
        pred=torch.stack((pred[:,0].sigmoid(),pred[:,1]*5.),1).numpy()
    report={**meta,'training_worlds':training,'validation_worlds':validation,'best_epoch':bestepoch,
        'epochs':a.epochs,'split_seed':getattr(a,'split_seed',None) or a.seed,'seed':a.seed,'batch_size':a.batch_size,'hidden':a.hidden,
        'device':a.device,'torch_version':torch.__version__,'cuda_runtime':torch.version.cuda,
        'gpu':torch.cuda.get_device_name(a.device) if a.device.startswith('cuda') else None,
        'training_wall_seconds':time.perf_counter()-started,'validation_loss':bestloss,
        'validation_success_mae':float(abs(pred[:,0]-y[va,0]).mean()),
        'validation_J_mae':float(abs(pred[:,1]-y[va,1]).mean()),
        'validation_loss_history':history,
        'data_sha256':hashlib.sha256(a.data.read_bytes()).hexdigest(),
        'normalization_fitted_on_training_only':True,
        'training_type':'supervised synthetic continuation approximation; not reinforcement learning'}
    # Candidate ranking agreement on held-out worlds, in addition to regression errors.
    agreements=[];truth=y[va];vg=groups[va]
    for g in np.unique(vg):
        ids=np.flatnonzero(vg==g)
        truebest=min(ids,key=lambda i:(-truth[i,0],truth[i,1],int(i)))
        chosen=min(ids,key=lambda i:(-pred[i,0],pred[i,1],int(i)))
        agreements.append(int(chosen==truebest))
    report['validation_top1_agreement']=float(np.mean(agreements))
    w={'mean':mean,'scale':scale,'metadata':json.dumps(report)}
    for num,layer in enumerate((0,2,4),1):
        w[f'w{num}']=best[f'{layer}.weight'].numpy().T;w[f'b{num}']=best[f'{layer}.bias'].numpy()
    a.out.parent.mkdir(parents=True,exist_ok=True)
    with a.out.open('wb') as f: np.savez_compressed(f,**w)
    report['model_sha256']=hashlib.sha256(a.out.read_bytes()).hexdigest()
    a.out.with_suffix('.training.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('validation_loss_history','training_worlds','validation_worlds')}))

if __name__=='__main__':
    import os
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--device',default='cpu');p.add_argument('--epochs',type=int,default=100)
    p.add_argument('--batch-size',type=int,default=2048);p.add_argument('--hidden',type=int,default=128)
    p.add_argument('--seed',type=int,default=1401);p.add_argument('--lr',type=float,default=.001)
    p.add_argument('--threads',type=int,default=1)
    train(p.parse_args())
