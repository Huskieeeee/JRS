#!/usr/bin/env python3
"""Bind one checkpoint/device to a predefined campaign; keep old freezes intact."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]


def prepare(stage,model,device,out):
    config=json.loads((ROOT/f'configs/v15_{stage}_template.json').read_text())
    path=model.resolve()
    with np.load(path,allow_pickle=False) as z:meta=json.loads(str(z['metadata']))
    if meta.get('ensemble_schema')!='return-ensemble-v1':raise ValueError('v1.5 ensemble required')
    worlds={f"{config['split']}:{i}" for i in range(config['world_start'],config['world_start']+len(config['layouts'])*config['worlds_per_layout'])}
    if worlds & (set(meta['training_worlds'])|set(meta['validation_worlds'])):raise ValueError('Test/train overlap')
    try:model_path=str(path.relative_to(ROOT))
    except ValueError:model_path=str(path)
    config['planning_budget'].update(release_model_path=model_path,
        release_model_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),release_device=device)
    if out.exists():
        if json.loads(out.read_text())!=config:raise ValueError('Existing config differs; use a new output/config name')
    else:
        out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(config,indent=2)+'\n')
    print(out)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['preflight','main','compute'],required=True)
    p.add_argument('--model',type=Path,required=True);p.add_argument('--device',default='cuda');p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();prepare(a.stage,a.model,a.device,a.out)
