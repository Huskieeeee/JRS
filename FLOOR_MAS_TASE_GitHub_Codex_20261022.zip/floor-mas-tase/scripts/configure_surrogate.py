#!/usr/bin/env python3
"""Bind a trained weight hash to a NEW paired evaluation configuration."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True)
    p.add_argument('--model',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--device',default='cpu');p.add_argument('--shortlist',type=int,default=4)
    a=p.parse_args()
    if a.out.exists(): raise SystemExit('Output config exists; choose a new filename')
    c=json.loads(a.base.read_text())
    with np.load(a.model,allow_pickle=False) as z: meta=json.loads(str(z['metadata']))
    count=len(c['layouts'])*c['worlds_per_layout']
    keys={f"{c['split']}:{i}" for i in range(c['world_start'],c['world_start']+count)}
    if keys & (set(meta['training_worlds'])|set(meta['validation_worlds'])):
        raise SystemExit('Evaluation worlds overlap fitting worlds')
    c['planning_budget'].update(surrogate_path=str(a.model.resolve()),
        surrogate_sha256=hashlib.sha256(a.model.read_bytes()).hexdigest(),
        surrogate_device=a.device,surrogate_shortlist=a.shortlist)
    c['methods']=list(dict.fromkeys(['jrs_evidence_screened']+c['methods']))
    c['primary_method']='jrs_evidence_screened'
    a.out.parent.mkdir(parents=True,exist_ok=True)
    a.out.write_text(json.dumps(c,indent=2)+'\n')
    print(a.out)
