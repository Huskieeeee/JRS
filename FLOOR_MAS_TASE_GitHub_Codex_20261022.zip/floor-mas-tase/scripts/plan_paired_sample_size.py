#!/usr/bin/env python3
"""Approximate paired binary design size; a planning calculation, not a test."""
import argparse
import math
from scipy.stats import norm

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--effect',type=float,default=.10,help='absolute completion-rate difference')
    p.add_argument('--discordance',type=float,default=.30,help='P(only one of paired methods succeeds)')
    p.add_argument('--comparisons',type=int,default=8)
    p.add_argument('--power',type=float,default=.80)
    x=p.parse_args()
    if not 0<x.effect<=x.discordance<=1 or x.comparisons<1 or not .5<x.power<1:raise ValueError('invalid design inputs')
    z=norm.ppf(1-.05/(2*x.comparisons))+norm.ppf(x.power)
    n=math.ceil(z*z*(x.discordance-x.effect*x.effect)/(x.effect*x.effect))
    print({'approx_worlds':n,'balanced_three_layout_worlds':3*math.ceil(n/3),
        'approximation':'normal approximation to paired binary difference, Bonferroni design alpha; verify by simulation',
        'unit':'independent physical worlds, not episodes or planner repetitions'})
