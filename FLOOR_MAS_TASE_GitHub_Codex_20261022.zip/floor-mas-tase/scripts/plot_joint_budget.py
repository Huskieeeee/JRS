#!/usr/bin/env python3
"""Plot measured compute versus outcome; no equivalent-CPU claim from caps."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--analyses',nargs='+',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    x=p.parse_args();groups={}
    for folder in x.analyses:
        a=json.loads((folder/'analysis.json').read_text())
        for row in a['summary']:groups.setdefault((row['condition'],row['method']),[]).append(row)
    conditions=sorted({c for c,m in groups});fig,axes=plt.subplots(len(conditions),2,figsize=(12,3.4*len(conditions)),squeeze=False)
    for index,c in enumerate(conditions):
        for (condition,method),rows in groups.items():
            if condition!=c:continue
            rows.sort(key=lambda r:r['planner_cpu_seconds'])
            xs=[r['planner_cpu_seconds'] for r in rows]
            axes[index,0].plot(xs,[100*r['qualified_completion'] for r in rows],'-o',label=method)
            axes[index,1].plot(xs,[r['J'] for r in rows],'-o',label=method)
        for ax in axes[index]:ax.set_title(c);ax.set_xlabel('Measured planning CPU seconds / episode');ax.grid(alpha=.25)
        axes[index,0].set_ylabel('Qualified completion (%)');axes[index,1].set_ylabel('Unconditional J')
    h,l=axes[0,0].get_legend_handles_labels();fig.legend(h,l,loc='upper center',ncol=3,fontsize=8)
    fig.tight_layout(rect=(0,0,1,.95));x.out.mkdir(parents=True,exist_ok=True)
    fig.savefig(x.out/'compute_tradeoff.png',dpi=160);fig.savefig(x.out/'compute_tradeoff.pdf');plt.close(fig)
