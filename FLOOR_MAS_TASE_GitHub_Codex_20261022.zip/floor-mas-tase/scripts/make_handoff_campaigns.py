#!/usr/bin/env python3
"""Generate optional development compute/scale campaigns before viewing results.

Scale changes cells AND regions: 12/24/48 cells correspond to 12/24/48 successor
tasks. Compute conditions intentionally reuse identical world definitions across
separate directories; they must not be pooled as independent worlds.
"""
import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def generate():
    base = json.loads((ROOT/'configs/handoff_development.json').read_text())
    out = ROOT/'configs/generated'
    out.mkdir(parents=True, exist_ok=True)
    for level, candidates in enumerate((2, 4, 8)):
        cfg = copy.deepcopy(base)
        cfg.update(split='handoff_compute', world_start=9400000,
                   methods=['fixed_jrs','fixed_random','certificate_window','handoff'])
        cfg['planning_budget'].update(max_candidates=candidates*4, handoff_candidates=candidates)
        (out/f'compute_{candidates}.json').write_text(json.dumps(cfg,indent=2)+'\n')
    for cells, regions in ((12,3),(24,6),(48,12)):
        for robots in (1,2,3):
            cfg = copy.deepcopy(base)
            cfg.update(split=f'handoff_scale_{cells}_{robots}', world_start=9500000+cells*1000+robots*100,
                       worlds_per_layout=10, methods=['fixed_random','certificate_window','handoff'])
            cfg['base_scenario'].update(n_cells=cells,n_regions=regions,robots_per_skill=robots,horizon=200)
            cfg['conditions']=[{'id':'base','changes':{}},
                               {'id':'collateral_off','changes':{'collateral_probability':0.,'assumed_collateral_probability':0.}}]
            (out/f'scale_{cells}cells_{robots*4}robots.json').write_text(json.dumps(cfg,indent=2)+'\n')
    print(out)

if __name__ == '__main__':
    generate()
