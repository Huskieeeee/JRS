#!/usr/bin/env python3
"""Fixed protocol ensemble fit on the existing v1.4 development trajectories."""
import argparse
import hashlib
import json
import os
from pathlib import Path
from types import SimpleNamespace
import time
import numpy as np
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
from train_surrogate import train


def main(a):
    if a.out.exists():raise ValueError('Model already exists; choose a new output path')
    begin=time.perf_counter();members=[];metas=[]
    for i in range(a.members):
        path=a.out.parent/(a.out.stem+f'_member{i}.npz')
        train(SimpleNamespace(data=a.data,out=path,device=a.device,epochs=a.epochs,batch_size=a.batch_size,
            hidden=128,seed=15100+i,split_seed=1501,lr=.001,threads=1))
        with np.load(path,allow_pickle=False) as z:
            members.append({k:z[k] for k in ('mean','scale','w1','b1','w2','b2','w3','b3')})
            metas.append(json.loads(str(z['metadata'])))
    assert all(m['training_worlds']==metas[0]['training_worlds'] and m['validation_worlds']==metas[0]['validation_worlds'] for m in metas)
    meta={'ensemble_schema':'return-ensemble-v1','feature_schema':metas[0]['feature_schema'],
        'training_worlds':metas[0]['training_worlds'],'validation_worlds':metas[0]['validation_worlds'],
        'teacher_target_protocol':metas[0]['target_protocol'],'members':a.members,
        'data_sha256':hashlib.sha256(a.data.read_bytes()).hexdigest(),'member_reports':metas,
        'training_wall_seconds':time.perf_counter()-begin,'training_device':a.device,
        'teacher':'v1.4 public-belief fixed-policy continuation returns',
        'deployment':'v1.5 baseline-anchored receding policy control; learned scores are approximations'}
    arrays={k:np.stack([m[k] for m in members]) for k in members[0]}
    with a.out.open('wb') as f:np.savez_compressed(f,metadata=json.dumps(meta),**arrays)
    meta['sha256']=hashlib.sha256(a.out.read_bytes()).hexdigest()
    a.out.with_suffix('.training.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(json.dumps({'model':str(a.out),'sha256':meta['sha256'],'members':a.members,
                      'training_wall_seconds':meta['training_wall_seconds'],'device':a.device}))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--data',type=Path,default=Path('datasets/v14_teacher.npz'))
    p.add_argument('--out',type=Path,default=Path('models/v15_ensemble_cuda.npz'))
    p.add_argument('--device',default='cuda');p.add_argument('--members',type=int,default=3)
    p.add_argument('--epochs',type=int,default=60);p.add_argument('--batch-size',type=int,default=1024)
    main(p.parse_args())
