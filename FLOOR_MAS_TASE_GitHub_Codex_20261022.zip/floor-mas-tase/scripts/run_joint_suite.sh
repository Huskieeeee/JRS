#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
stage="${1:-smoke}"
workers="${2:-4}"
case "$stage" in
  smoke|model_probe|pilot|main|ablation|robustness|transfer|ood_combo|holdout) configs=("joint_${stage}");;
  scale) configs=(joint_scale12 joint_scale24 joint_scale48);;
  budget) configs=(joint_budget1 joint_budget2 joint_budget4);;
  *) echo "Usage: bash scripts/run_joint_suite.sh smoke|model_probe|pilot|main|ablation|robustness|transfer|scale|ood_combo|budget|holdout [workers]"; exit 2;;
esac
for cfg in "${configs[@]}"; do
  python -u scripts/run_handoff_round.py --config "configs/${cfg}.json" --out "results/server_v13_${cfg}" --workers "$workers"
  python scripts/summarize_handoff.py --run "results/server_v13_${cfg}" --out "analysis/server_v13_${cfg}"
  python scripts/report_joint.py --run "results/server_v13_${cfg}" --analysis "analysis/server_v13_${cfg}"
done
