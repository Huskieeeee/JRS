#!/usr/bin/env python3
"""All-control readout, decision latency and unconditional cost-tail evidence."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def report(run, out):
    import sys
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
    from floor_tase.joint_recovery import empirical_cvar
    a=json.loads((out/'analysis.json').read_text())
    groups={}
    for f in sorted((run/'jobs').glob('*/result.json')):
        r=json.loads(f.read_text()); key=(r['job']['condition'],r['job']['method'])
        g=groups.setdefault(key,{'J':[],'cpu':[],'wall':[],'false':0,'stale':0,'quality_false':0,'rejections':0,'provider':0,'decisions':0})
        m=r['metrics'];g['J'].append(m['J'])
        for k,col in [('false','false_releases'),('stale','stale_authorizations'),
                      ('quality_false','quality_false_releases'),('rejections','action_rejections')]:g[k]+=m[col]
        d=json.loads((f.parent/'decisions.json').read_text())
        g['cpu'].extend(x['cpu_seconds'] for x in d)
        g['wall'].extend(x['wall_seconds'] for x in d)
        g['decisions']+=len(d)
        g['provider']+=sum('provider' in x.get('diagnostics',{}).get('selected',{}).get('sources',[]) for x in d)
    rows=[]
    for (condition,method),g in groups.items():
        rows.append({'condition':condition,'method':method,'episodes':len(g['J']),
            'J_cvar90':empirical_cvar(g['J'],.9),
            'decision_wall_p50':float(np.quantile(g['wall'],.5)),
            'decision_wall_p95':float(np.quantile(g['wall'],.95)),
            'decision_wall_max':max(g['wall']),
            'decision_cpu_p50':float(np.quantile(g['cpu'],.5)),
            'decision_cpu_p95':float(np.quantile(g['cpu'],.95)),
            'decision_cpu_max':max(g['cpu']),
            'provider_selection_fraction':g['provider']/max(1,g['decisions']),
            **{k:g[k] for k in ('false','stale','quality_false','rejections')}})
    with (out/'tail_latency_quality.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    lines=['# 全部基线配对对照','',
        '完成差为百分点；J差为新方法减对照，负值更好。置信区间按基础世界、布局分层配对计算。',
        'Holm校正沿用每个完整实验内的全部对照×条件，两个指标分别成族；不能跨文件挑选显著项。','',
        '| 条件 | 对照 | 完成差pp | 95%区间pp | J差 | 95%区间 | 完成Holm p | J Holm p |',
        '|---|---|---:|---|---:|---|---:|---:|']
    for r in a['comparisons']:
        lines.append(f"|{r['condition']}|{r['control']}|{100*r['completion_difference']:.2f}|"
            f"{[round(x*100,2) for x in r['completion_ci95']]}|{r['J_difference']:.4f}|"
            f"{[round(x,4) for x in r['J_ci95']]}|{r['completion_holm_p_exploratory']:.4f}|{r['J_holm_p_exploratory']:.4f}|")
    lines+=['','尾部J、决策延迟和质量指标：`tail_latency_quality.csv`。',
            'CPU未加入原J；所有失败回合均保留。曲线位置同时呈现效能和计算代价。',
            '3世界smoke每布局只有1世界，分层重抽样区间可退化；只检查执行链路。']
    (out/'ALL_BASELINES_ZH.md').write_text('\n'.join(lines)+'\n')
    conditions=list(dict.fromkeys(r['condition'] for r in a['summary']))
    fig,axes=plt.subplots(len(conditions),2,figsize=(12,3.5*len(conditions)),squeeze=False)
    for i,c in enumerate(conditions):
        for r in a['summary']:
            if r['condition']!=c:continue
            axes[i,0].scatter(r['planner_cpu_seconds'],100*r['qualified_completion'],label=r['method'])
            axes[i,1].scatter(r['planner_cpu_seconds'],r['J'],label=r['method'])
        for ax in axes[i]:ax.set_xlabel('Planning CPU seconds / episode');ax.set_title(c);ax.grid(alpha=.25)
        axes[i,0].set_ylabel('Qualified completion (%)');axes[i,1].set_ylabel('Unconditional J (lower better)')
    handles,labels=axes[0,0].get_legend_handles_labels()
    fig.legend(handles,labels,loc='upper center',ncol=3,fontsize=8)
    fig.tight_layout(rect=(0,0,1,.94));fig.savefig(out/'quality_cost_cpu.png',dpi=150);plt.close(fig)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--analysis',type=Path,required=True)
    x=p.parse_args();report(x.run,x.analysis)
