#!/usr/bin/env python3
"""Same-candidate prediction diagnostics, with actual-world access ONLY in evaluator.

Candidates are executed once and followed by robust_local in both prediction
and evaluation. This does not test continual deployment of a critic. Branches
and synthetic samples are not independent physical worlds.
"""
from __future__ import annotations
import argparse
import copy
import csv
import importlib.util
import json
import pathlib
import sys
import time
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
spec = importlib.util.spec_from_file_location("prediction_runner", ROOT / "scripts" / "run_repair_round.py")
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


def restore_environment(job, config, decisions, index):
    from floor_tase.environment import RecoveryEnv
    from floor_tase.model import Action
    scenario, _ = runner.scenario_for(job, config)
    env = RecoveryEnv(scenario)
    for record in decisions[:index]:
        actions = tuple(Action(**a) for a in record["actions"])
        if actions:
            env.step_joint(actions)
        else:
            env.advance()
    return env


def reference_rollout(real_env, candidate, seed):
    """Evaluator-only branch; never passed to any planner or predictor."""
    from floor_tase.planners import PublicPlanner
    env = copy.deepcopy(real_env)
    obs = env.observe()
    planner = PublicPlanner("robust_local", seed=seed)
    for packet in obs.pending_inspections:
        planner._pending_inspections[packet.view_id] = (packet.delivery_time, dict(packet.captured_versions))
    for action in obs.active:
        if action.kind == "inspect":
            planner._pending_inspections[action.target_id] = (action.finish + obs.measurement_delay,
                {cid: next(c.version for c in obs.cells if c.id == cid) for cid in action.cells})
    env.step_joint(candidate)
    steps = 1
    while not env.done and steps < 2000:
        action = planner.select(env.observe(), env.allowed_actions())
        env.step_joint(action)
        steps += 1
    if not env.done:
        raise RuntimeError("Evaluator continuation cap reached")
    result = env.result()
    result["new_jobs"] = len(set(env._jobs) - {j.id for j in obs.jobs})
    return result, env.get_trace()


def fixed_candidates(obs, allowed, job, count):
    from floor_tase.deterministic_legacy import FixedBudgetPlanner
    from floor_tase.window_planner import WindowPlanner
    from floor_tase.planners import PublicPlanner
    budget = job["budget"]
    candidates = []
    for name in ("jrs", "random_rollout"):
        p = FixedBudgetPlanner(name=name, seed=job["planner_seed"], max_candidates=budget["max_candidates"], cover_nodes=budget["cover_nodes"])
        candidates.append(tuple(p.select(obs, allowed)))
    p = WindowPlanner(seed=job["planner_seed"], max_candidates=budget["max_candidates"], max_nodes=budget["window_nodes"])
    candidates.extend(p.candidate_actions(obs, allowed))
    candidates.append(tuple(PublicPlanner("robust_local", seed=job["planner_seed"]).select(obs, allowed)))
    # Add deterministic single legal actions only when the planning shortlist
    # collapses. The shortlist is built ONCE, before any model predictions.
    candidates.extend((a,) for a in sorted(allowed, key=lambda a:(a.kind,a.robot_id,a.target_id,a.mode)))
    seen, selected = set(), []
    for candidate in candidates:
        key = runner.digest(runner.canonical(candidate))
        if key not in seen:
            selected.append(candidate)
            seen.add(key)
        if len(selected) >= count:
            break
    return selected


def diagnostic(run_dir, out, samples=8, worlds_per_layout=2, candidates=4):
    from floor_tase.model import Action
    from floor_tase.prediction import PublicPredictionModel, observation_from_dict, one_step_repair_predictions
    from floor_tase.environment import audit_trace
    config = runner.load_json(run_dir / "protocol.json")
    all_jobs = list(runner.jobs_for(config))
    selection = [j for j in all_jobs if j["method"] == "fixed_jrs" and j["planner_replicate"] == 0 and j["world_replicate"] < worlds_per_layout]
    identity = {"schema":"fixed-candidate-prediction-1", "input_freeze":runner.digest((run_dir / "FREEZE.json").read_bytes()),
                "source":runner.source_identity(), "samples":samples, "worlds_per_layout":worlds_per_layout,
                "max_candidates":candidates, "snapshot_indices":[0,5], "jobs_sha256":runner.digest(runner.canonical(selection)),
                "continuation":"robust_local_after_single_intervention", "selection":"first two replicate indices in each layout, fixed_jrs trajectories, every condition"}
    out.mkdir(parents=True, exist_ok=True)
    freeze_path = out / "FREEZE.json"
    if freeze_path.exists():
        if runner.load_json(freeze_path) != identity:
            raise RuntimeError("Prediction resume identity changed")
    else:
        if any(out.iterdir()):
            raise RuntimeError("Prediction output lacks a freeze")
        runner.write_json(freeze_path, identity)
    rows, event_rows, missing_snapshots = [], [], []
    for job in selection:
        folder = run_dir / "jobs" / job["job_id"]
        runner.audit_saved(folder, job)
        decisions = runner.load_json(folder / "decisions.json")
        snapshots = {s["decision_index"]:s for s in runner.load_json(folder / "public_snapshots.json")}
        for index in identity["snapshot_indices"]:
            key = f"{job['job_id']}__d{index}"
            cache_path = out / "snapshots" / (key + ".json")
            if index not in snapshots:
                missing_snapshots.append({"job":job["job_id"],"decision":index,"reason":"episode ended before fixed snapshot"})
                continue
            if cache_path.exists():
                cached = runner.load_json(cache_path)
                if cached["source_snapshot_sha256"] != runner.digest(runner.canonical(snapshots[index])):
                    raise RuntimeError("Input snapshot changed")
                for artifact, expected in cached["artifacts"].items():
                    if runner.digest((out / artifact).read_bytes()) != expected:
                        raise RuntimeError("Prediction trace changed")
                rows.extend(cached["rows"])
                event_rows.extend(cached["event_rows"])
                continue
            start = time.perf_counter()
            obs = observation_from_dict(snapshots[index]["observation"])
            allowed = tuple(Action(**a) for a in snapshots[index]["allowed_actions"])
            real_env = restore_environment(job, config, decisions, index)
            if runner.canonical(real_env.observe()) != runner.canonical(obs):
                raise RuntimeError("Replay differs from stored public observation")
            pool = fixed_candidates(obs, allowed, job, candidates)
            model_seed = runner.stable_seed("prediction", job["world_id"], index)
            forecasts = {mode:PublicPredictionModel(mode=mode,samples=samples,seed=model_seed).evaluate(obs,pool)
                         for mode in ("optimistic","collateral","cascade")}
            hashes = {mode:[p.candidate_id for p in pred] for mode,pred in forecasts.items()}
            if len({tuple(ids) for ids in hashes.values()}) != 1:
                raise RuntimeError("Prediction models did not evaluate the same candidate sequence")
            local_rows, local_events, artifacts = [], [], {}
            for candidate_index,candidate in enumerate(pool):
                truth, trace = reference_rollout(real_env,candidate,model_seed)
                audit = audit_trace(trace)
                if not audit["pass"]:
                    raise RuntimeError("Evaluator branch audit failed")
                trace_relative = f"evaluator_traces/{key}__c{candidate_index}.jsonl"
                trace_path = out / trace_relative
                trace_path.parent.mkdir(parents=True,exist_ok=True)
                with trace_path.open("w") as stream:
                    for event in trace:
                        stream.write(json.dumps(event,sort_keys=True)+"\n")
                artifacts[trace_relative] = runner.digest(trace_path.read_bytes())
                for mode,pred in forecasts.items():
                    value=pred[candidate_index]
                    row={"world_id":job["world_id"],"layout":job["layout"],"condition":job["condition"],
                         "decision_index":index,"candidate_index":candidate_index,"candidate_id":value.candidate_id,
                         "mode":mode,"samples":samples,"predicted_J":value.mean_J,"prediction_MC_se_J":value.se_J,
                         "actual_J":truth["J"],"J_absolute_error":abs(value.mean_J-truth["J"]),
                         "predicted_completion":value.completion_probability,"actual_completion":int(truth["quality_success"]),
                         "completion_brier":(value.completion_probability-int(truth["quality_success"]))**2,
                         "predicted_repairs":value.mean_repairs,"actual_repairs":truth["repairs"],
                         "predicted_new_jobs":value.mean_discovered_repairs,"actual_new_jobs":truth["new_jobs"],
                         "actual_false_releases":truth["false_releases"],"evaluator_audit_pass":audit["pass"],
                         "candidate_actions":runner.safe(candidate),"approximation_flags":value.approximation_flags}
                    local_rows.append(row)
                    for event_prediction in one_step_repair_predictions(obs,candidate,mode):
                        matched = [e for e in trace if e["event"]=="repair_complete" and e.get("job")==event_prediction["job"]
                            and e.get("mode")==event_prediction["mode"] and e.get("attempt")==event_prediction["attempt"]]
                        if len(matched)>1:
                            raise RuntimeError("Repeated repair attempt identity")
                        if not matched:
                            local_events.append({"world_id":job["world_id"],"condition":job["condition"],"decision_index":index,
                                "candidate_index":candidate_index,"prediction_mode":mode,**event_prediction,"status":"censored_before_completion"})
                        else:
                            field="evaluator_failed_targets" if event_prediction["event"]=="repair_failure" else "evaluator_bad_collateral"
                            outcome=int(event_prediction["cell"] in matched[0][field])
                            local_events.append({"world_id":job["world_id"],"condition":job["condition"],"decision_index":index,
                                "candidate_index":candidate_index,"prediction_mode":mode,**event_prediction,"status":"observed",
                                "outcome":outcome,"brier":(event_prediction["probability"]-outcome)**2})
            cached={"source_snapshot_sha256":runner.digest(runner.canonical(snapshots[index])),"candidate_hashes":hashes,
                    "rows":local_rows,"event_rows":local_events,"artifacts":artifacts,"wall_seconds":time.perf_counter()-start}
            runner.write_json(cache_path,cached)
            rows.extend(local_rows);event_rows.extend(local_events)
            print(json.dumps({"snapshot":key,"candidates":len(pool),"wall_seconds":cached["wall_seconds"]}),flush=True)
    rankings=[]
    grouped={}
    for row in rows:
        grouped.setdefault((row["world_id"],row["condition"],row["decision_index"],row["mode"]),[]).append(row)
    for (world,condition,index,mode),group in grouped.items():
        comparisons=[]
        for i,a in enumerate(group):
            for b in group[:i]:
                actual=a["actual_J"]-b["actual_J"]
                predicted=a["predicted_J"]-b["predicted_J"]
                if abs(actual)>1e-12:
                    comparisons.append(.5 if abs(predicted)<=1e-12 else float(actual*predicted>0))
        selected=min(group,key=lambda r:(r["predicted_J"],r["candidate_index"]))
        rankings.append({"world_id":world,"condition":condition,"decision_index":index,"mode":mode,
                         "informative_pairs":len(comparisons),
                         "pairwise_cost_ranking_accuracy":float(np.mean(comparisons)) if comparisons else None,
                         "realized_J_selection_regret":selected["actual_J"]-min(r["actual_J"] for r in group),
                         "regret_reference":"minimum realized J among same finite evaluator branches; not an online baseline"})
    # World-weighted means: average candidates and snapshots within each
    # physical world/condition first, so a variable shortlist creates no weight.
    summary=[]
    for condition in sorted({r["condition"] for r in rows}):
        for mode in ("optimistic","collateral","cascade"):
            group=[r for r in rows if r["condition"]==condition and r["mode"]==mode]
            byworld={w:[r for r in group if r["world_id"]==w] for w in sorted({r["world_id"] for r in group})}
            summary.append({"condition":condition,"mode":mode,"worlds":len(byworld),"candidate_forecasts":len(group),
                            **{metric:float(np.mean([np.mean([r[metric] for r in records]) for records in byworld.values()]))
                               for metric in ("J_absolute_error","completion_brier")}})
    runner.write_json(out / "prediction_rows.json",rows)
    runner.write_json(out / "one_step_rows.json",event_rows)
    runner.write_json(out / "ranking_rows.json",rankings)
    runner.write_json(out / "SUMMARY.json",{"status":"complete_exploratory_prediction_diagnostic","summary":summary,
        "unique_worlds":len({r["world_id"] for r in rows}),"candidate_forecasts":len(rows),
        "missing_fixed_snapshots":missing_snapshots,"candidate_identity_verified":True,
        "notes":["True state and copied actual environments are evaluator-only.",
                 "Every mode evaluates identical candidate actions at identical public snapshots.",
                 "Target is one intervention followed by fixed robust_local, not deployment performance.",
                 "Synthetic samples and multiple branches are not independent physical replicates.",
                 "One-step known-parameter Brier scores check simulator prediction fidelity; they are not learned calibration evidence.",
                 "Return errors also contain partial-observation belief approximation and Monte Carlo error.",
                 "Candidate ranking rows must be aggregated within world before inference; no branch-level significance claims."]})
    return 0


if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run",required=True,type=pathlib.Path)
    p.add_argument("--out",required=True,type=pathlib.Path)
    p.add_argument("--samples",type=int,default=8)
    p.add_argument("--worlds-per-layout",type=int,default=2)
    p.add_argument("--candidates",type=int,default=4)
    a=p.parse_args()
    raise SystemExit(diagnostic(a.run,a.out,a.samples,a.worlds_per_layout,a.candidates))
