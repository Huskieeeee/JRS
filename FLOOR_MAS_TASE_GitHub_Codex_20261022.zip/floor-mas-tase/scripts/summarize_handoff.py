#!/usr/bin/env python3
"""Produce paired tables and a concise Chinese readout from a complete campaign."""
import argparse
import json
from pathlib import Path
from analyze_repair_round import analyze

LABELS = {'jrs_release':'v1.5联合恢复','jrs_release_no_chain':'移除恢复链检查','jrs_release_no_commit':'移除阶段续接','jrs_release_no_gate':'移除基线收益门槛','jrs_evidence':'证据续接v1.4','jrs_evidence_no_guard':'v1.4移除证据保护','jrs_evidence_single':'v1.4单续接','jrs_evidence_handoff':'v1.4原续接','jrs_evidence_screened':'v1.4学习筛选','jrs_joint_central_no_tail':'中心模型无尾部成本','jrs_joint': '联合恢复v1.3', 'arch_staged': '分阶段架构', 'arch_dispatch': '事件驱动派发',
          'jrs_joint_dispatch': '派发器+联合恢复', 'jrs_joint_central': '仅中心模型',
          'jrs_joint_no_provider': '移除基线候选', 'jrs_joint_no_tail': '移除尾部成本',
          'jrs_joint_local_scope': '仅局部返工', 'jrs_joint_no_diagnostic': '关闭提前诊断',
          'jrs_joint_global_wait': '全局交接等待',
          'jrs_joint_dispatch_continuation': '替换续接策略', 'fixed_jrs': 'JRS', 'fixed_random': '随机候选', 'certificate_window': '原窗口法',
          'handoff_adaptive': '自适应交接v1.2',
          'handoff_adaptive_always_diagnostic': 'v1.2始终允许诊断',
          'handoff_adaptive_no_fast': 'v1.2关闭快速派发',
          'handoff_adaptive_no_protection': 'v1.2关闭交接保护候选',
          'handoff_adaptive_full_risk': 'v1.2仅风险模型评分',
          'handoff_adaptive_local_scope': 'v1.2固定局部范围',
          'handoff': '交接导向完整方法', 'handoff_rule': '交接导向规则',
          'handoff_no_diagnostic': '关闭提前诊断', 'handoff_global_wait': '全局等待',
          'handoff_local_scope': '固定局部范围', 'handoff_optimistic': '乐观预测',
          'handoff_cascade': '级联预测'}

def summarize(run, out):
    report = analyze(run, out)
    lines = ['# 交接导向算法：开发实验结果', '',
             f"完成 {report['episodes']} 回合；{report['unique_worlds']} 个独立基础世界；"
             f"轨迹审计 {report['structural_events_audited']} 条事件。", '',
             '这是新开发实验，条件派生与方法重复均在基础世界内配对。', '',
             '| 条件 | 方法 | 合格完成 | J↓ | 团队等待↓ | 检查 | 后继撤销 | 规划CPU秒/回合 |',
             '|---|---|---:|---:|---:|---:|---:|---:|']
    for r in report['summary']:
        lines.append(f"| {r['condition']} | {LABELS.get(r['method'],r['method'])} | "
                     f"{r['qualified_completion_count']:g}/{r['worlds']} | {r['J']:.4f} | "
                     f"{r['waiting_time']:.2f} | {r['inspections']:.2f} | {r['successor_revocations']:.2f} | "
                     f"{r['planner_cpu_seconds']:.3f} |")
    lines += ['', '## 与强随机候选对照的配对差', '',
              '| 条件 | 完成差（百分点） | 完成差95%区间 | J差 | J差95%区间 | 完成Holm p | J Holm p |',
              '|---|---:|---|---:|---|---:|---:|']
    for r in report['comparisons']:
        if r['control'] == 'fixed_random':
            ci = [round(100*x, 2) for x in r['completion_ci95']]
            lines.append(f"| {r['condition']} | {100*r['completion_difference']:.2f} | {ci} | "
                         f"{r['J_difference']:.4f} | {[round(x,4) for x in r['J_ci95']]} | "
                         f"{r['completion_holm_p_exploratory']:.4f} | {r['J_holm_p_exploratory']:.4f} |")
    lines += ['', 'CPU为实测值；候选数、节点数与合成预测样本数不是等价计算预算。',
              '完整配对差、失败世界、原始轨迹与逐决策预测可用于后续诊断；本表不合并历史确认数据。',
              '窗口法与新方法的差包含候选生成和预测方式变化；各开关消融用于识别具体机制。', '']
    (out/'RESULTS_ZH.md').write_text('\n'.join(lines))
    # Index concrete counterexamples without dropping either direction.
    rows = [json.loads(p.read_text()) for p in sorted((run/'jobs').glob('*/result.json'))]
    lookup = {(r['job']['world_id'], r['job']['condition'], r['job']['method'], r['job']['planner_replicate']): r for r in rows}
    witnesses = []
    for key, r in lookup.items():
        w, c, method, rep = key
        if method != report.get('primary_method', 'handoff'): continue
        other = lookup.get((w, c, 'fixed_random', rep))
        if other is None: continue
        if r['metrics']['quality_success'] != other['metrics']['quality_success']:
            witnesses.append({'world': w, 'condition': c, 'planner_replicate':rep,
                              'handoff_success': r['metrics']['quality_success'],
                              'random_success': other['metrics']['quality_success'],
                              'handoff_job': r['job']['job_id'], 'random_job': other['job']['job_id']})
    (out/'discordant_worlds.json').write_text(json.dumps(witnesses, indent=2)+'\n')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    summarize(args.run, args.out)
