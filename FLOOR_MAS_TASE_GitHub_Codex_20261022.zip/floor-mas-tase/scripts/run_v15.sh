#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."
stage="${1:-preflight}"
workers="${2:-1}"
device="${3:-cuda}"
model="${4:-models/v15_ensemble_cpu.npz}"
case "$device" in
  cuda*) python scripts/check_gpu.py --require-cuda ;;
  cpu) python scripts/check_gpu.py ;;
  *) echo "Use cpu or cuda[:index]" >&2; exit 2 ;;
esac
case "$stage" in
  all) stages=(preflight main) ;;
  preflight|main|compute) stages=("$stage") ;;
  *) echo "stage: preflight|main|compute|all" >&2; exit 2 ;;
esac
device_tag="${device//:/_}"
for current in "${stages[@]}"; do
  config="configs/generated/v15_${current}_${device_tag}.json"
  run="results/server_v15_${current}_${device_tag}"
  analysis="analysis/server_v15_${current}_${device_tag}"
  python scripts/prepare_v15_campaign.py --stage "$current" --model "$model" --device "$device" --out "$config"
  python -u scripts/run_handoff_round.py --config "$config" --out "$run" --workers "$workers"
  python scripts/report_v15.py --run "$run" --out "$analysis"
done
