#!/usr/bin/env python3
"""Read v1.2 cap2/cap6 summaries without rerunning or changing their freeze."""
import argparse
import csv
from pathlib import Path
from collections import defaultdict
import numpy as np
from analyze_repair_round import bootstrap_ci, csv_write


def compare(left,right,out):
    def load(path):
        rows=list(csv.DictReader((path/'episodes.csv').open()))
        lookup={}
        for r in rows:
            key=(r['world_id'],r['condition'],r['method'],r['planner_replicate'])
            if key in lookup:raise ValueError('duplicate episode')
            lookup[key]=r
        return lookup
    a,b=load(left),load(right)
    if a.keys()!=b.keys():raise ValueError('cap2/cap6 episodes are not fully paired')
    if any(a[k]['base_world_sha256']!=b[k]['base_world_sha256'] for k in a):
        raise ValueError('world identities differ')
    groups=defaultdict(list)
    for k in a:groups[(k[1],k[2])].append(k)
    results=[]
    for (c,m),keys in sorted(groups.items()):
        # Average planner repeats within physical world before resampling.
        worlds=defaultdict(list)
        for k in keys:worlds[k[0]].append(k)
        for metric in ('qualified_completion','J','planner_cpu_seconds'):
            vals=[float(np.mean([float(b[k][metric])-float(a[k][metric]) for k in ks])) for ks in worlds.values()]
            strata=[a[ks[0]]['layout'] for ks in worlds.values()]
            results.append({'condition':c,'method':m,'metric':metric,'cap6_minus_cap2':float(np.mean(vals)),
                            'ci95':bootstrap_ci(vals,strata),'worlds':len(worlds)})
    out.mkdir(parents=True,exist_ok=True);csv_write(out/'rank_probe_budget_effects.csv',results)
    print('Saved',out/'rank_probe_budget_effects.csv')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cap2',type=Path,required=True);p.add_argument('--cap6',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    x=p.parse_args();compare(x.cap2,x.cap6,x.out)
