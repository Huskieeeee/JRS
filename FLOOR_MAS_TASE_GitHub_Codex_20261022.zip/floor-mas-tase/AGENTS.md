# FLOOR-MAS T-ASE / JRS-RG

## Goal and orientation

This is a Python research simulator for joint rework, recertification, and successor handoff. Research release v1.6; engineering package 0.6.1. Communicate with the user in Chinese. Explain research contributions through domain problems and corresponding mechanisms. Distinguish measured evidence from design targets.

Read `README.md`, `docs/ARCHITECTURE_ZH.md`, and `docs/DEVELOPMENT_ZH.md` for orientation. The current method is `recovery_graph.py`; variant switches are in `rg_variants.py`. Shared physical dynamics and original J live in `model.py` and `environment.py`. Campaign implementation is in `src/floor_tase/experiments/`. `scripts/` includes compatibility wrappers used by existing server commands.

## Setup and verification

Use Python 3.12 for the reference development environment. Python >=3.10 is supported. Install with `bash scripts/dev/setup.sh`; run `bash scripts/dev/check.sh`. CPU development does not require Torch. No API key is needed to run this project. If dependencies are already provisioned and network is unavailable, use `FLOOR_TASE_OFFLINE=1 bash scripts/dev/setup.sh`.

For targeted changes, run the relevant unit tests, then the six-job developer check (`python -m floor_tase smoke --out results/dev_<change> --workers 1`). The full verification entry point is `bash scripts/dev/check.sh`. Use a new output path after source changes. The standard v1.6 all-method smoke has 198 jobs; main has 66,000. Routine development uses the six-job check. Run costly campaigns when the task requires them and record what was actually run.

## Implementation conventions

- Put reusable implementation in `src/floor_tase/`; use package-relative imports in the experiment package. Preserve compatibility script names.
- Keep CPU as the normal development path. Explicit CUDA requests must fail clearly if CUDA is unavailable. Use an existing validated server Torch installation for GPU work.
- Keep paired physical worlds, sensor seeds, planner seeds, original J, and quality/deadline definitions consistent across methods unless the requested research change requires otherwise. Document intentional changes.
- Preserve trace audits, model checksums, source freeze, resume identities, and failed episodes. New source or protocol means a new output directory. Never hand-edit reference results to match newer code.
- Keep generated outputs out of Git. `validation/reference_v1_6/` is historical evidence; new validation belongs in `validation/local/` or a clearly labeled report.
- Add behavior-focused regression tests when changing scientific logic or the runner. Do not add dependencies for a task already handled by the standard library.
- Report changed behavior, checks run, limitations, and next work plainly. Do not claim a GPU result based on CPU tests.

## Code Review Rules

Flag accidental changes to paired job identities, hidden world information entering planners, altered cost/quality definitions, silent CPU fallback after explicit CUDA selection, and comparisons that drop failed worlds. Confirm subprocess worker functions remain importable with multiprocessing spawn and compatibility scripts continue to route into the package.
