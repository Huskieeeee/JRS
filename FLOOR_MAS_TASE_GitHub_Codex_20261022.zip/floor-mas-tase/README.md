# FLOOR-MAS · T-ASE / JRS-RG

面向多机器人返工、质量复检与后继任务交接的可复现实验项目。研究版本为 **v1.6**，本次工程整理包版本为 **0.6.1**。

主方法通过恢复依赖图组织行动，批量评估随机完成时间，并按事件续接执行。研究动机与实验设计见 [三问题与三方案](docs/INNOVATION_AND_EXPERIMENTS_ZH.md)。

## 快速开始：CPU 开发

建议使用 Python 3.12；项目支持 Python ≥3.10。日常开发无需 Torch 或 GPU。

```bash
python3 -m venv .venv
source .venv/bin/activate
bash scripts/dev/setup.sh
bash scripts/dev/check.sh
```

安装脚本使用当前 Python 安装可编辑包。`check.sh` 执行编译、Shell 语法检查、机制测试、模型校验和 6 回合端到端检查；输出位于临时目录，执行后清理。

也可使用 Conda：`conda env create -f environment.yml && conda activate floor-tase-dev`。已有服务器 `jrs` 环境可直接 `python -m pip install -e .`，保留已经验证的 Torch/CUDA 安装。

```bash
floor-tase doctor
floor-tase smoke --out results/dev_smoke --workers 1
```

`floor-tase` 与 `python -m floor_tase` 等价。开发 smoke 使用独立开发种子、1 个布局、3 条件和 2 方法，共 6 回合；v1.6 全方法 smoke 仍为 198 回合。

## 项目入口

| 位置 | 职责 |
|---|---|
| `src/floor_tase/model.py`、`environment.py` | 场景、动作、质量状态、物理执行和轨迹审计 |
| `src/floor_tase/recovery_graph.py`、`rg_variants.py` | JRS-RG 图编译、随机传播、事件续接与消融 |
| `src/floor_tase/experiments/` | 配置、运行、冻结、统计、报告、绘图与分片合并 |
| `src/floor_tase/cli.py` | 统一命令行入口 |
| `scripts/` | 兼容旧命令的入口及历史实验工具 |
| `configs/v15_main_template.json` | v1.6 使用的基础配置模板 |
| `models/` | 原版固定集成模型与训练元数据 |
| `tests/` | 算法机制和实验流程回归测试 |
| `validation/reference_v1_6/` | 原包验证报告与冻结元数据，仅作历史参考 |
| `docs/` | 架构、Codex 配置、实验方法和迁移说明 |

新开发优先修改 `src/` 中的实现；旧脚本兼容层不再复制算法。详细依赖见 [架构说明](docs/ARCHITECTURE_ZH.md)。

## 全量实验与 GPU

```bash
# 原有 CPU 全方法 smoke：198 回合，含报告
bash scripts/run_v16.sh smoke 1 cpu

# 已有 CUDA 环境：检查设备、执行 smoke、做 CPU/CUDA 一致性测试
python scripts/check_gpu.py --require-cuda
CUDA_VISIBLE_DEVICES=4 bash scripts/run_v16.sh smoke 1 cuda
CUDA_VISIBLE_DEVICES=4 floor-tase benchmark --device cuda

# 开发 probe 与主实验
CUDA_VISIBLE_DEVICES=4 bash scripts/run_v16.sh probe 1 cuda
CUDA_VISIBLE_DEVICES=4 bash scripts/run_v16.sh main 1 cuda
# 或选择多 GPU 分片
bash scripts/run_v16_multi.sh main 4,5
```

GPU 编号按服务器实际空闲设备选择。新机器的 Torch 安装应匹配服务器驱动；默认开发安装不安装 Torch。`gpu` 可选依赖仅给出版本范围，不替代驱动匹配。

| 阶段 | 基础世界 | 条件 | 方法 | 回合 |
|---|---:|---:|---:|---:|
| 开发快速检查 | 1 | 3 | 2 | 6 |
| v1.6 smoke | 3 | 3 | 22 | 198 |
| v1.6 probe | 12 | 3 | 22 | 792 |
| v1.6 main | 600 | 5 | 22 | 66,000 |

仅生成配置或冻结任务单：

```bash
floor-tase prepare smoke --device cpu
floor-tase run --config configs/generated/v16_smoke_cpu_0of1.json \
  --out results/my_v16_smoke --workers 1 --freeze-only
```

`--help` 列出命令参数；所有旧的 `python scripts/prepare_v16.py` 等命令仍可使用。

## GitHub 与 Codex

- [Codex 环境配置](docs/CODEX_SETUP_ZH.md)：安装命令、环境变量、云环境发布、第一条开发任务。
- [开发约定](AGENTS.md)：项目目标、代码定位、检查命令与实验规范。
- `.github/workflows/ci.yml`：每次 push/PR 配置 Python 3.10、3.12 的 CPU 检查。
- `.devcontainer/devcontainer.json`：VS Code / Codespaces 的 Python 3.12 CPU 开发容器。
- [上传说明](docs/GITHUB_ZH.md)：新建私有仓库与命令行上传。

## 数据与结果

`results/`、`analysis/`、`logs/`、`configs/generated/` 和临时缓存不进入 Git。原始 ZIP 中约 50 MB 的逐回合轨迹保留在原始文件中，仓库只保留参考报告、配置和冻结记录。大规模实验输出保存在服务器，并通过代码提交、配置、模型散列和冻结信息关联。

本次整理保持 JRS-RG 核心、模型、目标函数、种子、方法集合与原配置一致。原版验证报告属于原源码快照。重组改变源码散列，**新实验使用新输出目录**，不续跑原包已经冻结的目录。

参考验证只说明该版本能够执行；算法性能以独立实验为准。已知研究待办见 [后续开发任务](docs/DEVELOPMENT_ZH.md)。未指定开源许可证，默认保留作者权利。
