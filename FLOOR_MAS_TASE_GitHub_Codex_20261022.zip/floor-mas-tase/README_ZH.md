# 中文使用说明

当前中文项目入口为 [README.md](README.md)。

原 v1.6 交付说明保存在 [docs/archive/README_v1_6.md](docs/archive/README_v1_6.md)，其中服务器绝对路径是历史示例。当前安装与 Codex 开发请按新 README 操作。
